"use client"

import { useState, useEffect } from "react"
import { Navigation } from "@/components/navigation"
import { TrendsChart } from "@/components/analytics/trends-chart"
import { StatisticsCards } from "@/components/analytics/statistics-cards"
import { CorrelationCharts } from "@/components/analytics/correlation-charts"
import { TopAssetsTable } from "@/components/analytics/top-assets-table"
import { Card, CardContent } from "@/components/ui/card"

interface AnalyticsData {
  trends: Array<{
    date: string
    High: number
    Medium: number
    Low: number
    total: number
  }>
  statistics: {
    overview: {
      totalEvents: number
      analyzedEvents: number
      confirmedAttacks: number
      falsePositiveRate: number
      avgAnalysisTimeMinutes: number
    }
    topTargetedAssets: Array<{
      asset: string
      totalEvents: number
      highPriorityEvents: number
      riskScore: number
    }>
    attackVectors: Array<{
      eventType: string
      totalAttempts: number
      confirmedAttacks: number
      confirmationRate: number
      avgAnomalyScore: number
    }>
  }
  correlation: {
    criticalityCorrelation: Array<{
      assetCriticality: string
      High: number
      Medium: number
      Low: number
      total: number
    }>
    timePatterns: Array<{
      hour: number
      High: number
      Medium: number
      Low: number
      total: number
    }>
  }
}

export default function AnalyticsPage() {
  const [analyticsData, setAnalyticsData] = useState<AnalyticsData | null>(null)
  const [loading, setLoading] = useState(true)
  const [timeRange, setTimeRange] = useState("7d")

  useEffect(() => {
    async function fetchAnalyticsData() {
      try {
        setLoading(true)
        const [trendsRes, statisticsRes, correlationRes] = await Promise.all([
          fetch(`/api/analytics/trends?timeRange=${timeRange}`),
          fetch("/api/analytics/statistics"),
          fetch("/api/analytics/correlation"),
        ])

        const [trendsData, statisticsData, correlationData] = await Promise.all([
          trendsRes.json(),
          statisticsRes.json(),
          correlationRes.json(),
        ])

        setAnalyticsData({
          trends: trendsData.trends || [],
          statistics: statisticsData,
          correlation: correlationData,
        })
      } catch (error) {
        console.error("Error fetching analytics data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchAnalyticsData()
  }, [timeRange])

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
          <div className="flex items-center justify-center h-64">
            <div className="text-lg text-muted-foreground">Loading analytics...</div>
          </div>
        </main>
      </div>
    )
  }

  if (!analyticsData) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
          <Card>
            <CardContent className="flex items-center justify-center h-64">
              <div className="text-center">
                <p className="text-lg text-muted-foreground mb-2">Failed to load analytics</p>
                <p className="text-sm text-muted-foreground">Please try refreshing the page</p>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground">Security Analytics</h1>
          <p className="text-muted-foreground">Advanced analysis and insights into security threats and patterns</p>
        </div>

        <div className="space-y-8">
          {/* Statistics Overview */}
          <StatisticsCards statistics={analyticsData.statistics} />

          {/* Trends Chart */}
          <TrendsChart data={analyticsData.trends} timeRange={timeRange} onTimeRangeChange={setTimeRange} />

          {/* Correlation Charts */}
          <CorrelationCharts data={analyticsData.correlation} />

          {/* Top Targeted Assets */}
          <TopAssetsTable assets={analyticsData.statistics.topTargetedAssets} />
        </div>
      </main>
    </div>
  )
}
