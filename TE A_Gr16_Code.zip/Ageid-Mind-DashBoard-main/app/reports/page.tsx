"use client"

import { useState } from "react"
import { Navigation } from "@/components/navigation"
import { ReportGenerator, type ReportConfig } from "@/components/reports/report-generator"
import { ReportPreview } from "@/components/reports/report-preview"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { FileText, Clock, Download } from "lucide-react"

interface GeneratedReport {
  reportData: any
  metadata: {
    reportType: string
    dateRange: string
    startDate: string
    endDate: string
    generatedAt: string
    format: string
  }
}

export default function ReportsPage() {
  const [generatedReport, setGeneratedReport] = useState<GeneratedReport | null>(null)
  const [isGenerating, setIsGenerating] = useState(false)
  const [recentReports] = useState([
    {
      id: "1",
      name: "Weekly Security Summary",
      type: "security_summary",
      generatedAt: "2025-01-09T10:30:00Z",
      dateRange: "week",
    },
    {
      id: "2",
      name: "Monthly Incident Report",
      type: "incident_report",
      generatedAt: "2025-01-08T15:45:00Z",
      dateRange: "month",
    },
    {
      id: "3",
      name: "Executive Summary",
      type: "executive_summary",
      generatedAt: "2025-01-07T09:15:00Z",
      dateRange: "quarter",
    },
  ])

  const handleGenerateReport = async (config: ReportConfig) => {
    setIsGenerating(true)
    try {
      const response = await fetch("/api/reports/generate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(config),
      })

      if (!response.ok) {
        throw new Error("Failed to generate report")
      }

      const data = await response.json()
      setGeneratedReport(data)
    } catch (error) {
      console.error("Error generating report:", error)
      // Handle error (show toast, etc.)
    } finally {
      setIsGenerating(false)
    }
  }

  const handleDownloadReport = () => {
    if (!generatedReport) return

    const dataStr = JSON.stringify(generatedReport, null, 2)
    const dataBlob = new Blob([dataStr], { type: "application/json" })
    const url = URL.createObjectURL(dataBlob)
    const link = document.createElement("a")
    link.href = url
    link.download = `security-report-${generatedReport.metadata.reportType}-${new Date().toISOString().split("T")[0]}.json`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)
  }

  const getReportTypeLabel = (type: string) => {
    switch (type) {
      case "security_summary":
        return "Security Summary"
      case "incident_report":
        return "Incident Report"
      case "trend_analysis":
        return "Trend Analysis"
      case "executive_summary":
        return "Executive Summary"
      default:
        return type
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground">Security Reports</h1>
          <p className="text-muted-foreground">Generate and export comprehensive security reports and summaries</p>
        </div>

        <div className="grid gap-8 lg:grid-cols-3">
          {/* Report Generator */}
          <div className="lg:col-span-1">
            <div className="space-y-6">
              <ReportGenerator onGenerateReport={handleGenerateReport} isGenerating={isGenerating} />

              {/* Recent Reports */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Clock className="h-5 w-5" />
                    Recent Reports
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {recentReports.map((report) => (
                      <div key={report.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div>
                          <div className="font-medium text-sm">{report.name}</div>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge variant="outline" className="text-xs">
                              {getReportTypeLabel(report.type)}
                            </Badge>
                            <span className="text-xs text-muted-foreground">
                              {new Date(report.generatedAt).toLocaleDateString()}
                            </span>
                          </div>
                        </div>
                        <button className="text-muted-foreground hover:text-foreground">
                          <Download className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Report Preview */}
          <div className="lg:col-span-2">
            {generatedReport ? (
              <ReportPreview
                reportData={generatedReport.reportData}
                metadata={generatedReport.metadata}
                onDownload={handleDownloadReport}
              />
            ) : (
              <Card>
                <CardContent className="flex items-center justify-center h-96">
                  <div className="text-center">
                    <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-semibold mb-2">No Report Generated</h3>
                    <p className="text-muted-foreground">
                      Select a report type and date range to generate your security report
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}
