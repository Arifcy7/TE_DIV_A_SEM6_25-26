import { type NextRequest, NextResponse } from "next/server"
import { getSecurityEventById, getSecurityAnalysisByEventId, getRelatedEvents } from "@/lib/db-operations"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { id } = params

    const [event, analysis, relatedEvents] = await Promise.all([
      getSecurityEventById(id),
      getSecurityAnalysisByEventId(id),
      // We'll get related events after we have the main event
      Promise.resolve([]),
    ])

    if (!event) {
      return NextResponse.json({ error: "Event not found" }, { status: 404 })
    }

    // Get related events based on the main event's properties
    const related = await getRelatedEvents(event.source_ip, event.event_type, id)

    return NextResponse.json({
      event,
      analysis,
      relatedEvents: related,
    })
  } catch (error) {
    console.error("Error fetching event details:", error)
    return NextResponse.json({ error: "Failed to fetch event details" }, { status: 500 })
  }
}
