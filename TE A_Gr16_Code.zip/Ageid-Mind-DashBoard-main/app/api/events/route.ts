import { type NextRequest, NextResponse } from "next/server"
import { getSecurityEventsWithAnalysis } from "@/lib/db-operations"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)

    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "20")
    const urgency = searchParams.get("urgency") || undefined
    const event_type = searchParams.get("event_type") || undefined
    const source_ip = searchParams.get("source_ip") || undefined
    const attack_confirmed = searchParams.get("attack_confirmed")
      ? searchParams.get("attack_confirmed") === "true"
      : undefined
    const date_from = searchParams.get("date_from") ? new Date(searchParams.get("date_from")!) : undefined
    const date_to = searchParams.get("date_to") ? new Date(searchParams.get("date_to")!) : undefined
    const search = searchParams.get("search") || undefined

    const filters = {
      urgency,
      event_type,
      source_ip,
      attack_confirmed,
      date_from,
      date_to,
    }

    // Remove undefined values
    Object.keys(filters).forEach((key) => {
      if (filters[key as keyof typeof filters] === undefined) {
        delete filters[key as keyof typeof filters]
      }
    })

    const { events, total } = await getSecurityEventsWithAnalysis(page, limit, filters)

    // Apply search filter if provided (simple text search)
    let filteredEvents = events
    if (search) {
      const searchLower = search.toLowerCase()
      filteredEvents = events.filter(
        (event) =>
          event.source_ip.toLowerCase().includes(searchLower) ||
          event.destination.toLowerCase().includes(searchLower) ||
          event.event_type.toLowerCase().includes(searchLower) ||
          (event.username && event.username.toLowerCase().includes(searchLower)),
      )
    }

    return NextResponse.json({
      events: filteredEvents,
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
    })
  } catch (error) {
    console.error("Error fetching events:", error)
    return NextResponse.json({ error: "Failed to fetch events" }, { status: 500 })
  }
}
