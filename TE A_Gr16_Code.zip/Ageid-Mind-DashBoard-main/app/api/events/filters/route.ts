import { NextResponse } from "next/server"
import { getDatabase } from "@/lib/mongodb"
import type { SecurityEvent } from "@/lib/types"

export async function GET() {
  try {
    const db = await getDatabase()
    const eventsCollection = db.collection<SecurityEvent>("security_events")

    // Get unique values for filters
    const [eventTypes, sourceIPs] = await Promise.all([
      eventsCollection.distinct("event_type"),
      eventsCollection.distinct("source_ip"),
    ])

    return NextResponse.json({
      eventTypes: eventTypes.sort(),
      sourceIPs: sourceIPs.sort(),
      urgencyLevels: ["Low", "Medium", "High"],
    })
  } catch (error) {
    console.error("Error fetching filter options:", error)
    return NextResponse.json({ error: "Failed to fetch filter options" }, { status: 500 })
  }
}
