import { type NextRequest, NextResponse } from "next/server"
import { getDatabase } from "@/lib/mongodb"
import type { SecurityEvent, SecurityAnalysis } from "@/lib/types"

export async function POST(request: NextRequest) {
  try {
    const { reportType, dateRange, format } = await request.json()

    const db = await getDatabase()
    const eventsCollection = db.collection<SecurityEvent>("security_events")
    const analysisCollection = db.collection<SecurityAnalysis>("security_analysis")

    // Calculate date range
    const now = new Date()
    let startDate: Date
    let endDate = now

    switch (dateRange) {
      case "today":
        startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate())
        break
      case "yesterday":
        startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1)
        endDate = new Date(now.getFullYear(), now.getMonth(), now.getDate())
        break
      case "week":
        startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)
        break
      case "month":
        startDate = new Date(now.getFullYear(), now.getMonth(), 1)
        break
      case "quarter":
        const quarterStart = Math.floor(now.getMonth() / 3) * 3
        startDate = new Date(now.getFullYear(), quarterStart, 1)
        break
      default:
        startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)
    }

    // Generate report based on type
    let reportData: any

    switch (reportType) {
      case "security_summary":
        reportData = await generateSecuritySummary(eventsCollection, analysisCollection, startDate, endDate)
        break
      case "incident_report":
        reportData = await generateIncidentReport(eventsCollection, analysisCollection, startDate, endDate)
        break
      case "trend_analysis":
        reportData = await generateTrendAnalysis(eventsCollection, startDate, endDate)
        break
      case "executive_summary":
        reportData = await generateExecutiveSummary(eventsCollection, analysisCollection, startDate, endDate)
        break
      default:
        return NextResponse.json({ error: "Invalid report type" }, { status: 400 })
    }

    return NextResponse.json({
      reportData,
      metadata: {
        reportType,
        dateRange,
        startDate: startDate.toISOString(),
        endDate: endDate.toISOString(),
        generatedAt: now.toISOString(),
        format,
      },
    })
  } catch (error) {
    console.error("Error generating report:", error)
    return NextResponse.json({ error: "Failed to generate report" }, { status: 500 })
  }
}

async function generateSecuritySummary(eventsCollection: any, analysisCollection: any, startDate: Date, endDate: Date) {
  const [totalEvents, highPriorityEvents, confirmedAttacks, eventsByType, topSourceIPs] = await Promise.all([
    eventsCollection.countDocuments({ timestamp: { $gte: startDate, $lte: endDate } }),
    eventsCollection.countDocuments({
      timestamp: { $gte: startDate, $lte: endDate },
      final_urgency: "High",
    }),
    eventsCollection.countDocuments({
      timestamp: { $gte: startDate, $lte: endDate },
      attack_confirmed: true,
    }),
    eventsCollection
      .aggregate([
        { $match: { timestamp: { $gte: startDate, $lte: endDate } } },
        { $group: { _id: "$event_type", count: { $sum: 1 } } },
        { $sort: { count: -1 } },
      ])
      .toArray(),
    eventsCollection
      .aggregate([
        { $match: { timestamp: { $gte: startDate, $lte: endDate } } },
        { $group: { _id: "$source_ip", count: { $sum: 1 } } },
        { $sort: { count: -1 } },
        { $limit: 10 },
      ])
      .toArray(),
  ])

  return {
    overview: {
      totalEvents,
      highPriorityEvents,
      confirmedAttacks,
      falsePositiveRate: totalEvents > 0 ? ((totalEvents - confirmedAttacks) / totalEvents) * 100 : 0,
    },
    eventsByType,
    topSourceIPs,
  }
}

async function generateIncidentReport(eventsCollection: any, analysisCollection: any, startDate: Date, endDate: Date) {
  const incidents = await eventsCollection
    .find({
      timestamp: { $gte: startDate, $lte: endDate },
      attack_confirmed: true,
      final_urgency: { $in: ["High", "Medium"] },
    })
    .sort({ timestamp: -1 })
    .toArray()

  const incidentDetails = await Promise.all(
    incidents.map(async (incident: any) => {
      const analysis = await analysisCollection.findOne({ event_id: incident.event_id })
      return {
        ...incident,
        analysis,
      }
    }),
  )

  return {
    totalIncidents: incidents.length,
    highPriorityIncidents: incidents.filter((i: any) => i.final_urgency === "High").length,
    incidents: incidentDetails,
  }
}

async function generateTrendAnalysis(eventsCollection: any, startDate: Date, endDate: Date) {
  const dailyTrends = await eventsCollection
    .aggregate([
      { $match: { timestamp: { $gte: startDate, $lte: endDate } } },
      {
        $group: {
          _id: {
            date: { $dateToString: { format: "%Y-%m-%d", date: "$timestamp" } },
            urgency: "$final_urgency",
          },
          count: { $sum: 1 },
        },
      },
      {
        $group: {
          _id: "$_id.date",
          High: { $sum: { $cond: [{ $eq: ["$_id.urgency", "High"] }, "$count", 0] } },
          Medium: { $sum: { $cond: [{ $eq: ["$_id.urgency", "Medium"] }, "$count", 0] } },
          Low: { $sum: { $cond: [{ $eq: ["$_id.urgency", "Low"] }, "$count", 0] } },
          total: { $sum: "$count" },
        },
      },
      { $sort: { _id: 1 } },
    ])
    .toArray()

  return {
    dailyTrends,
    summary: {
      totalDays: dailyTrends.length,
      avgEventsPerDay: dailyTrends.reduce((sum: number, day: any) => sum + day.total, 0) / dailyTrends.length || 0,
      peakDay: dailyTrends.reduce((max: any, day: any) => (day.total > (max?.total || 0) ? day : max), null),
    },
  }
}

async function generateExecutiveSummary(
  eventsCollection: any,
  analysisCollection: any,
  startDate: Date,
  endDate: Date,
) {
  const [totalEvents, confirmedAttacks, highPriorityEvents, topThreats, criticalAssets, responseMetrics] =
    await Promise.all([
      eventsCollection.countDocuments({ timestamp: { $gte: startDate, $lte: endDate } }),
      eventsCollection.countDocuments({
        timestamp: { $gte: startDate, $lte: endDate },
        attack_confirmed: true,
      }),
      eventsCollection.countDocuments({
        timestamp: { $gte: startDate, $lte: endDate },
        final_urgency: "High",
      }),
      eventsCollection
        .aggregate([
          {
            $match: {
              timestamp: { $gte: startDate, $lte: endDate },
              attack_confirmed: true,
            },
          },
          { $group: { _id: "$event_type", count: { $sum: 1 } } },
          { $sort: { count: -1 } },
          { $limit: 5 },
        ])
        .toArray(),
      eventsCollection
        .aggregate([
          {
            $match: {
              timestamp: { $gte: startDate, $lte: endDate },
              asset_criticality: "high",
            },
          },
          { $group: { _id: "$destination", count: { $sum: 1 } } },
          { $sort: { count: -1 } },
          { $limit: 5 },
        ])
        .toArray(),
      eventsCollection
        .aggregate([
          {
            $match: {
              timestamp: { $gte: startDate, $lte: endDate },
              status: "analyzed",
              analyzed_timestamp: { $exists: true },
            },
          },
          {
            $project: {
              responseTime: { $subtract: ["$analyzed_timestamp", "$stored_timestamp"] },
            },
          },
          {
            $group: {
              _id: null,
              avgResponseTime: { $avg: "$responseTime" },
              maxResponseTime: { $max: "$responseTime" },
            },
          },
        ])
        .toArray(),
    ])

  return {
    keyMetrics: {
      totalEvents,
      confirmedAttacks,
      highPriorityEvents,
      threatLevel: highPriorityEvents > 10 ? "High" : highPriorityEvents > 5 ? "Medium" : "Low",
    },
    topThreats,
    criticalAssets,
    responseMetrics: responseMetrics[0] || { avgResponseTime: 0, maxResponseTime: 0 },
    recommendations: generateRecommendations(totalEvents, confirmedAttacks, highPriorityEvents),
  }
}

function generateRecommendations(totalEvents: number, confirmedAttacks: number, highPriorityEvents: number) {
  const recommendations = []

  if (highPriorityEvents > 10) {
    recommendations.push("Consider increasing security monitoring and response team capacity")
  }

  if (confirmedAttacks / totalEvents > 0.1) {
    recommendations.push("Review and strengthen security controls - high attack confirmation rate detected")
  }

  if (totalEvents > 1000) {
    recommendations.push("Implement automated threat response for common attack patterns")
  }

  if (recommendations.length === 0) {
    recommendations.push("Security posture appears stable - continue current monitoring practices")
  }

  return recommendations
}
