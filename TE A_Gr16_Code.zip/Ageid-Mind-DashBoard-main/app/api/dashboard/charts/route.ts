import { NextResponse } from "next/server"
import { getEventTypeDistribution, getUrgencyDistribution, getTopSourceIPs } from "@/lib/db-operations"

export async function GET() {
  try {
    const [eventTypes, urgencyDistribution, topSourceIPs] = await Promise.all([
      getEventTypeDistribution(),
      getUrgencyDistribution(),
      getTopSourceIPs(),
    ])

    return NextResponse.json({
      eventTypes,
      urgencyDistribution,
      topSourceIPs,
    })
  } catch (error) {
    console.error("Error fetching chart data:", error)
    return NextResponse.json({ error: "Failed to fetch chart data" }, { status: 500 })
  }
}
