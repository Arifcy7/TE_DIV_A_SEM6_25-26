import { NextResponse } from "next/server"
import { getRecentEventsWithAnalysis } from "@/lib/db-operations"

export async function GET() {
  try {
    const events = await getRecentEventsWithAnalysis()
    return NextResponse.json(events)
  } catch (error) {
    console.error("Error fetching recent events:", error)
    return NextResponse.json({ error: "Failed to fetch recent events" }, { status: 500 })
  }
}
