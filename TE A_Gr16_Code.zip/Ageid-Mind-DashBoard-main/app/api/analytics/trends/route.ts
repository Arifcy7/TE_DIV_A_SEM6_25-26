import { type NextRequest, NextResponse } from "next/server"
import { getDatabase } from "@/lib/mongodb"
import type { SecurityEvent } from "@/lib/types"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const timeRange = searchParams.get("timeRange") || "7d"

    const db = await getDatabase()
    const eventsCollection = db.collection<SecurityEvent>("security_events")

    // Calculate date range
    const now = new Date()
    let startDate: Date
    switch (timeRange) {
      case "24h":
        startDate = new Date(now.getTime() - 24 * 60 * 60 * 1000)
        break
      case "7d":
        startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)
        break
      case "30d":
        startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000)
        break
      case "90d":
        startDate = new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000)
        break
      default:
        startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)
    }

    // Determine grouping interval based on time range
    let groupFormat: string
    let dateFormat: string
    if (timeRange === "24h") {
      groupFormat = "%Y-%m-%d %H:00:00"
      dateFormat = "hour"
    } else if (timeRange === "7d") {
      groupFormat = "%Y-%m-%d"
      dateFormat = "day"
    } else {
      groupFormat = "%Y-%m-%d"
      dateFormat = "day"
    }

    const pipeline = [
      {
        $match: {
          timestamp: { $gte: startDate },
        },
      },
      {
        $group: {
          _id: {
            date: { $dateToString: { format: groupFormat, date: "$timestamp" } },
            urgency: "$final_urgency",
          },
          count: { $sum: 1 },
        },
      },
      {
        $group: {
          _id: "$_id.date",
          High: {
            $sum: { $cond: [{ $eq: ["$_id.urgency", "High"] }, "$count", 0] },
          },
          Medium: {
            $sum: { $cond: [{ $eq: ["$_id.urgency", "Medium"] }, "$count", 0] },
          },
          Low: {
            $sum: { $cond: [{ $eq: ["$_id.urgency", "Low"] }, "$count", 0] },
          },
          total: { $sum: "$count" },
        },
      },
      {
        $sort: { _id: 1 },
      },
    ]

    const trends = await eventsCollection.aggregate(pipeline).toArray()

    return NextResponse.json({
      trends: trends.map((item) => ({
        date: item._id,
        High: item.High || 0,
        Medium: item.Medium || 0,
        Low: item.Low || 0,
        total: item.total || 0,
      })),
      timeRange,
      dateFormat,
    })
  } catch (error) {
    console.error("Error fetching trends:", error)
    return NextResponse.json({ error: "Failed to fetch trends" }, { status: 500 })
  }
}
