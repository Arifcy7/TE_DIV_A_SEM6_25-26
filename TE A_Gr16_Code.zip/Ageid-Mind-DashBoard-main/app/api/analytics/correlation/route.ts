import { NextResponse } from "next/server"
import { getDatabase } from "@/lib/mongodb"
import type { SecurityEvent } from "@/lib/types"

export async function GET() {
  try {
    const db = await getDatabase()
    const eventsCollection = db.collection<SecurityEvent>("security_events")

    // Asset criticality vs attack frequency correlation
    const criticalityCorrelation = await eventsCollection
      .aggregate([
        {
          $group: {
            _id: {
              asset_criticality: "$asset_criticality",
              final_urgency: "$final_urgency",
            },
            count: { $sum: 1 },
          },
        },
        {
          $group: {
            _id: "$_id.asset_criticality",
            High: {
              $sum: { $cond: [{ $eq: ["$_id.final_urgency", "High"] }, "$count", 0] },
            },
            Medium: {
              $sum: { $cond: [{ $eq: ["$_id.final_urgency", "Medium"] }, "$count", 0] },
            },
            Low: {
              $sum: { $cond: [{ $eq: ["$_id.final_urgency", "Low"] }, "$count", 0] },
            },
            total: { $sum: "$count" },
          },
        },
        {
          $sort: { _id: 1 },
        },
      ])
      .toArray()

    // Time-based attack patterns (hour of day analysis)
    const timePatterns = await eventsCollection
      .aggregate([
        {
          $project: {
            hour: { $hour: "$timestamp" },
            final_urgency: 1,
          },
        },
        {
          $group: {
            _id: {
              hour: "$hour",
              urgency: "$final_urgency",
            },
            count: { $sum: 1 },
          },
        },
        {
          $group: {
            _id: "$_id.hour",
            High: {
              $sum: { $cond: [{ $eq: ["$_id.urgency", "High"] }, "$count", 0] },
            },
            Medium: {
              $sum: { $cond: [{ $eq: ["$_id.urgency", "Medium"] }, "$count", 0] },
            },
            Low: {
              $sum: { $cond: [{ $eq: ["$_id.urgency", "Low"] }, "$count", 0] },
            },
            total: { $sum: "$count" },
          },
        },
        {
          $sort: { _id: 1 },
        },
      ])
      .toArray()

    return NextResponse.json({
      criticalityCorrelation: criticalityCorrelation.map((item) => ({
        assetCriticality: item._id,
        High: item.High || 0,
        Medium: item.Medium || 0,
        Low: item.Low || 0,
        total: item.total || 0,
      })),
      timePatterns: timePatterns.map((item) => ({
        hour: item._id,
        High: item.High || 0,
        Medium: item.Medium || 0,
        Low: item.Low || 0,
        total: item.total || 0,
      })),
    })
  } catch (error) {
    console.error("Error fetching correlation data:", error)
    return NextResponse.json({ error: "Failed to fetch correlation data" }, { status: 500 })
  }
}
