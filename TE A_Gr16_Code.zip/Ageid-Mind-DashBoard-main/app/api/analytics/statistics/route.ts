import { NextResponse } from "next/server"
import { getDatabase } from "@/lib/mongodb"
import type { SecurityEvent, SecurityAnalysis } from "@/lib/types"

export async function GET() {
  try {
    const db = await getDatabase()
    const eventsCollection = db.collection<SecurityEvent>("security_events")
    const analysisCollection = db.collection<SecurityAnalysis>("security_analysis")

    // Calculate various statistics
    const [
      totalEvents,
      analyzedEvents,
      confirmedAttacks,
      avgAnalysisTime,
      topTargetedAssets,
      attackVectors,
      successFailureRates,
    ] = await Promise.all([
      eventsCollection.countDocuments(),
      eventsCollection.countDocuments({ status: "analyzed" }),
      eventsCollection.countDocuments({ attack_confirmed: true }),

      // Average time to analysis
      eventsCollection
        .aggregate([
          {
            $match: {
              status: "analyzed",
              analyzed_timestamp: { $exists: true },
            },
          },
          {
            $project: {
              analysisTime: {
                $subtract: ["$analyzed_timestamp", "$stored_timestamp"],
              },
            },
          },
          {
            $group: {
              _id: null,
              avgTime: { $avg: "$analysisTime" },
            },
          },
        ])
        .toArray(),

      // Top targeted assets
      eventsCollection
        .aggregate([
          {
            $group: {
              _id: "$destination",
              count: { $sum: 1 },
              highPriorityCount: {
                $sum: { $cond: [{ $eq: ["$final_urgency", "High"] }, 1, 0] },
              },
            },
          },
          { $sort: { count: -1 } },
          { $limit: 10 },
        ])
        .toArray(),

      // Attack vectors (event types with success rates)
      eventsCollection
        .aggregate([
          {
            $group: {
              _id: "$event_type",
              total: { $sum: 1 },
              confirmed: {
                $sum: { $cond: [{ $eq: ["$attack_confirmed", true] }, 1, 0] },
              },
              avgAnomalyScore: { $avg: "$anomaly_score" },
            },
          },
          {
            $project: {
              event_type: "$_id",
              total: 1,
              confirmed: 1,
              confirmationRate: {
                $multiply: [{ $divide: ["$confirmed", "$total"] }, 100],
              },
              avgAnomalyScore: { $multiply: ["$avgAnomalyScore", 100] },
            },
          },
          { $sort: { total: -1 } },
        ])
        .toArray(),

      // Success/Failure rates for login attempts
      eventsCollection
        .aggregate([
          {
            $match: {
              event_type: "brute_force_login_attempt",
            },
          },
          {
            $group: {
              _id: "$success",
              count: { $sum: 1 },
            },
          },
        ])
        .toArray(),
    ])

    // Calculate false positive rate (assuming non-confirmed attacks are false positives)
    const falsePositiveRate = totalEvents > 0 ? ((totalEvents - confirmedAttacks) / totalEvents) * 100 : 0

    // Format average analysis time
    const avgTimeMs = avgAnalysisTime[0]?.avgTime || 0
    const avgTimeMinutes = Math.round(avgTimeMs / (1000 * 60))

    return NextResponse.json({
      overview: {
        totalEvents,
        analyzedEvents,
        confirmedAttacks,
        falsePositiveRate: Math.round(falsePositiveRate * 100) / 100,
        avgAnalysisTimeMinutes: avgTimeMinutes,
      },
      topTargetedAssets: topTargetedAssets.map((asset) => ({
        asset: asset._id,
        totalEvents: asset.count,
        highPriorityEvents: asset.highPriorityCount,
        riskScore: Math.round((asset.highPriorityCount / asset.count) * 100),
      })),
      attackVectors: attackVectors.map((vector) => ({
        eventType: vector.event_type,
        totalAttempts: vector.total,
        confirmedAttacks: vector.confirmed,
        confirmationRate: Math.round(vector.confirmationRate * 100) / 100,
        avgAnomalyScore: Math.round(vector.avgAnomalyScore * 100) / 100,
      })),
      successFailureRates: {
        successful: successFailureRates.find((r) => r._id === true)?.count || 0,
        failed: successFailureRates.find((r) => r._id === false)?.count || 0,
      },
    })
  } catch (error) {
    console.error("Error fetching statistics:", error)
    return NextResponse.json({ error: "Failed to fetch statistics" }, { status: 500 })
  }
}
