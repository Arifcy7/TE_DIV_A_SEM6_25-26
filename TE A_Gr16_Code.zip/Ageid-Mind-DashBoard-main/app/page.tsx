"use client"

import { useEffect, useState } from "react"
import { Navigation } from "@/components/navigation"
import { StatsCards } from "@/components/dashboard/stats-cards"
import { UrgencyPieChart } from "@/components/dashboard/urgency-pie-chart"
import { EventTypesChart } from "@/components/dashboard/event-types-chart"
import { RecentEvents } from "@/components/dashboard/recent-events"
import { TopSourceIPs } from "@/components/dashboard/top-source-ips"
import type {
  DashboardStats,
  UrgencyDistribution,
  EventTypeDistribution,
  TopSourceIP,
  SecurityEvent,
} from "@/lib/types"

export default function DashboardPage() {
  const [stats, setStats] = useState<DashboardStats | null>(null)
  const [chartData, setChartData] = useState<{
    eventTypes: EventTypeDistribution[]
    urgencyDistribution: UrgencyDistribution[]
    topSourceIPs: TopSourceIP[]
  } | null>(null)
  const [recentEvents, setRecentEvents] = useState<SecurityEvent[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchDashboardData() {
      try {
        const [statsRes, chartsRes, eventsRes] = await Promise.all([
          fetch("/api/dashboard/stats"),
          fetch("/api/dashboard/charts"),
          fetch("/api/dashboard/recent-events"),
        ])

        const [statsData, chartsData, eventsData] = await Promise.all([
          statsRes.json(),
          chartsRes.json(),
          eventsRes.json(),
        ])

        setStats(statsData)
        setChartData(chartsData)
        setRecentEvents(eventsData)
      } catch (error) {
        console.error("Error fetching dashboard data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchDashboardData()
  }, [])

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
          <div className="flex items-center justify-center h-64">
            <div className="text-lg text-muted-foreground">Loading dashboard...</div>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground">Security Dashboard</h1>
          <p className="text-muted-foreground">Monitor and analyze security threats in real-time</p>
        </div>

        {/* Stats Cards */}
        {stats && (
          <div className="mb-8">
            <StatsCards stats={stats} />
          </div>
        )}

        {/* Charts Section */}
        {chartData && (
          <div className="mb-8 grid gap-6 lg:grid-cols-2">
            <UrgencyPieChart data={chartData.urgencyDistribution} />
            <EventTypesChart data={chartData.eventTypes} />
          </div>
        )}

        {/* Recent Events and Top IPs */}
        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <RecentEvents events={recentEvents} />
          </div>
          <div>{chartData && <TopSourceIPs data={chartData.topSourceIPs} />}</div>
        </div>
      </main>
    </div>
  )
}
