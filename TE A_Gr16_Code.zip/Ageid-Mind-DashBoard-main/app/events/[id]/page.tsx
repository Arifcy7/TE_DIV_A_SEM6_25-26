"use client"

import { useState, useEffect } from "react"
import { useParams } from "next/navigation"
import { Navigation } from "@/components/navigation"
import { EventDetailsHeader } from "@/components/events/event-details-header"
import { RawEventData } from "@/components/events/raw-event-data"
import { AIAnalysisSection } from "@/components/events/ai-analysis-section"
import { RelatedEvents } from "@/components/events/related-events"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import type { SecurityEvent, SecurityAnalysis } from "@/lib/types"

interface EventDetailsResponse {
  event: SecurityEvent
  analysis: SecurityAnalysis | null
  relatedEvents: SecurityEvent[]
}

export default function EventDetailPage() {
  const params = useParams()
  const [eventData, setEventData] = useState<EventDetailsResponse | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function fetchEventDetails() {
      if (!params.id) return

      try {
        setLoading(true)
        const response = await fetch(`/api/events/${params.id}`)

        if (!response.ok) {
          if (response.status === 404) {
            setError("Event not found")
          } else {
            setError("Failed to load event details")
          }
          return
        }

        const data = await response.json()
        setEventData(data)
      } catch (error) {
        console.error("Error fetching event details:", error)
        setError("Failed to load event details")
      } finally {
        setLoading(false)
      }
    }

    fetchEventDetails()
  }, [params.id])

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
          <div className="flex items-center justify-center h-64">
            <div className="text-lg text-muted-foreground">Loading event details...</div>
          </div>
        </main>
      </div>
    )
  }

  if (error || !eventData) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
          <Card>
            <CardContent className="flex items-center justify-center h-64">
              <div className="text-center">
                <p className="text-lg text-muted-foreground mb-2">{error || "Event not found"}</p>
                <p className="text-sm text-muted-foreground">
                  The event you're looking for doesn't exist or has been removed.
                </p>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="space-y-8">
          {/* Event Header */}
          <EventDetailsHeader event={eventData.event} />

          {/* Main Content Tabs */}
          <Tabs defaultValue="analysis" className="space-y-6">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="analysis">AI Analysis</TabsTrigger>
              <TabsTrigger value="raw-data">Raw Event Data</TabsTrigger>
              <TabsTrigger value="related">Related Events</TabsTrigger>
            </TabsList>

            <TabsContent value="analysis" className="space-y-6">
              <AIAnalysisSection analysis={eventData.analysis} />
            </TabsContent>

            <TabsContent value="raw-data" className="space-y-6">
              <RawEventData event={eventData.event} />
            </TabsContent>

            <TabsContent value="related" className="space-y-6">
              <RelatedEvents events={eventData.relatedEvents} currentEventId={eventData.event._id?.toString() || ""} />
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
