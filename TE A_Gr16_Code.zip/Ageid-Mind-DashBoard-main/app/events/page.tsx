"use client"

import { useState, useEffect, useCallback } from "react"
import { Navigation } from "@/components/navigation"
import { EventFilters, type EventFilters as EventFiltersType } from "@/components/events/event-filters"
import { EventCard } from "@/components/events/event-card"
import { Pagination } from "@/components/events/pagination"
import { Card, CardContent } from "@/components/ui/card"
import type { SecurityEvent } from "@/lib/types"

interface EventsResponse {
  events: SecurityEvent[]
  total: number
  page: number
  limit: number
  totalPages: number
}

export default function EventsPage() {
  const [eventsData, setEventsData] = useState<EventsResponse | null>(null)
  const [loading, setLoading] = useState(true)
  const [currentPage, setCurrentPage] = useState(1)
  const [filters, setFilters] = useState<EventFiltersType>({})
  const [search, setSearch] = useState("")

  const fetchEvents = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams({
        page: currentPage.toString(),
        limit: "20",
        ...(search && { search }),
        ...Object.fromEntries(Object.entries(filters).map(([key, value]) => [key, String(value)])),
      })

      const response = await fetch(`/api/events?${params}`)
      const data = await response.json()
      setEventsData(data)
    } catch (error) {
      console.error("Error fetching events:", error)
    } finally {
      setLoading(false)
    }
  }, [currentPage, filters, search])

  useEffect(() => {
    fetchEvents()
  }, [fetchEvents])

  const handleFiltersChange = (newFilters: EventFiltersType) => {
    setFilters(newFilters)
    setCurrentPage(1) // Reset to first page when filters change
  }

  const handleSearch = (searchTerm: string) => {
    setSearch(searchTerm)
    setCurrentPage(1) // Reset to first page when search changes
  }

  const handlePageChange = (page: number) => {
    setCurrentPage(page)
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground">Security Events</h1>
          <p className="text-muted-foreground">
            Monitor and investigate security events with advanced filtering and search
          </p>
        </div>

        {/* Filters */}
        <div className="mb-6">
          <EventFilters onFiltersChange={handleFiltersChange} onSearch={handleSearch} />
        </div>

        {/* Results Summary */}
        {eventsData && (
          <div className="mb-4 flex items-center justify-between">
            <p className="text-sm text-muted-foreground">
              Showing {eventsData.events.length} of {eventsData.total} events
              {eventsData.totalPages > 1 && (
                <span>
                  {" "}
                  (Page {eventsData.page} of {eventsData.totalPages})
                </span>
              )}
            </p>
          </div>
        )}

        {/* Events List */}
        {loading ? (
          <div className="flex items-center justify-center h-64">
            <div className="text-lg text-muted-foreground">Loading events...</div>
          </div>
        ) : eventsData?.events.length === 0 ? (
          <Card>
            <CardContent className="flex items-center justify-center h-64">
              <div className="text-center">
                <p className="text-lg text-muted-foreground mb-2">No events found</p>
                <p className="text-sm text-muted-foreground">Try adjusting your filters or search criteria</p>
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {eventsData?.events.map((event) => (
              <EventCard key={event._id?.toString()} event={event} />
            ))}
          </div>
        )}

        {/* Pagination */}
        {eventsData && eventsData.totalPages > 1 && (
          <div className="mt-8">
            <Pagination
              currentPage={eventsData.page}
              totalPages={eventsData.totalPages}
              onPageChange={handlePageChange}
            />
          </div>
        )}
      </main>
    </div>
  )
}
