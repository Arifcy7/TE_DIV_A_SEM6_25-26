import { getDatabase } from "./mongodb"
import type {
  SecurityEvent,
  SecurityAnalysis,
  DashboardStats,
  EventTypeDistribution,
  UrgencyDistribution,
  TopSourceIP,
} from "./types"
import { ObjectId } from "mongodb"

export async function getDashboardStats(): Promise<DashboardStats> {
  const db = await getDatabase()
  const eventsCollection = db.collection<SecurityEvent>("security_events")

  const now = new Date()
  const twentyFourHoursAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000)

  const [totalEvents, highPriorityEvents24h, analyzedEvents, pendingEvents, confirmedAttacks] = await Promise.all([
    eventsCollection.countDocuments(),
    eventsCollection.countDocuments({
      final_urgency: "High",
      timestamp: { $gte: twentyFourHoursAgo },
    }),
    eventsCollection.countDocuments({ status: "analyzed" }),
    eventsCollection.countDocuments({ status: "pending_analysis" }),
    eventsCollection.countDocuments({ attack_confirmed: true }),
  ])

  return {
    totalEvents,
    highPriorityEvents24h,
    analyzedEvents,
    pendingEvents,
    confirmedAttacks,
  }
}

export async function getEventTypeDistribution(): Promise<EventTypeDistribution[]> {
  const db = await getDatabase()
  const eventsCollection = db.collection<SecurityEvent>("security_events")

  const pipeline = [
    {
      $group: {
        _id: "$event_type",
        count: { $sum: 1 },
      },
    },
    {
      $project: {
        event_type: "$_id",
        count: 1,
        _id: 0,
      },
    },
    { $sort: { count: -1 } },
  ]

  return await eventsCollection.aggregate<EventTypeDistribution>(pipeline).toArray()
}

export async function getUrgencyDistribution(): Promise<UrgencyDistribution[]> {
  const db = await getDatabase()
  const eventsCollection = db.collection<SecurityEvent>("security_events")

  const pipeline = [
    {
      $match: { final_urgency: { $exists: true } },
    },
    {
      $group: {
        _id: "$final_urgency",
        count: { $sum: 1 },
      },
    },
    {
      $project: {
        urgency: "$_id",
        count: 1,
        _id: 0,
      },
    },
  ]

  return await eventsCollection.aggregate<UrgencyDistribution>(pipeline).toArray()
}

export async function getTopSourceIPs(limit = 10): Promise<TopSourceIP[]> {
  const db = await getDatabase()
  const eventsCollection = db.collection<SecurityEvent>("security_events")

  const pipeline = [
    {
      $group: {
        _id: "$source_ip",
        count: { $sum: 1 },
      },
    },
    {
      $project: {
        source_ip: "$_id",
        count: 1,
        _id: 0,
      },
    },
    { $sort: { count: -1 } },
    { $limit: limit },
  ]

  return await eventsCollection.aggregate<TopSourceIP>(pipeline).toArray()
}

export async function getRecentEvents(limit = 5): Promise<SecurityEvent[]> {
  const db = await getDatabase()
  const eventsCollection = db.collection<SecurityEvent>("security_events")

  return await eventsCollection.find({}).sort({ timestamp: -1 }).limit(limit).toArray()
}

export async function getSecurityEvents(
  page = 1,
  limit = 20,
  filters: {
    urgency?: string
    event_type?: string
    source_ip?: string
    attack_confirmed?: boolean
    date_from?: Date
    date_to?: Date
  } = {},
): Promise<{ events: SecurityEvent[]; total: number }> {
  const db = await getDatabase()
  const eventsCollection = db.collection<SecurityEvent>("security_events")

  const query: any = {}

  if (filters.urgency) query.final_urgency = filters.urgency
  if (filters.event_type) query.event_type = filters.event_type
  if (filters.source_ip) query.source_ip = filters.source_ip
  if (filters.attack_confirmed !== undefined) query.attack_confirmed = filters.attack_confirmed
  if (filters.date_from || filters.date_to) {
    query.timestamp = {}
    if (filters.date_from) query.timestamp.$gte = filters.date_from
    if (filters.date_to) query.timestamp.$lte = filters.date_to
  }

  const skip = (page - 1) * limit

  const [events, total] = await Promise.all([
    eventsCollection.find(query).sort({ timestamp: -1 }).skip(skip).limit(limit).toArray(),
    eventsCollection.countDocuments(query),
  ])

  return { events, total }
}

export async function getSecurityEventById(id: string): Promise<SecurityEvent | null> {
  const db = await getDatabase()
  const eventsCollection = db.collection<SecurityEvent>("security_events")

  return await eventsCollection.findOne({ _id: new ObjectId(id) })
}

export async function getSecurityAnalysisByEventId(eventId: string): Promise<SecurityAnalysis | null> {
  const db = await getDatabase()
  const analysisCollection = db.collection<SecurityAnalysis>("security_analysis")

  return await analysisCollection.findOne({ event_id: eventId })
}

export async function getRelatedEvents(
  sourceIp: string,
  eventType: string,
  excludeId: string,
): Promise<SecurityEvent[]> {
  const db = await getDatabase()
  const eventsCollection = db.collection<SecurityEvent>("security_events")

  return await eventsCollection
    .find({
      $or: [{ source_ip: sourceIp }, { event_type: eventType }],
      _id: { $ne: new ObjectId(excludeId) },
    })
    .sort({ timestamp: -1 })
    .limit(10)
    .toArray()
}

export async function getSecurityEventsWithAnalysis(
  page = 1,
  limit = 20,
  filters: {
    urgency?: string
    event_type?: string
    source_ip?: string
    attack_confirmed?: boolean
    date_from?: Date
    date_to?: Date
  } = {},
): Promise<{ events: (SecurityEvent & { analysis?: SecurityAnalysis })[]; total: number }> {
  const db = await getDatabase()
  const eventsCollection = db.collection<SecurityEvent>("security_events")

  const query: any = {}

  if (filters.urgency) query.final_urgency = filters.urgency
  if (filters.event_type) query.event_type = filters.event_type
  if (filters.source_ip) query.source_ip = filters.source_ip
  if (filters.attack_confirmed !== undefined) query.attack_confirmed = filters.attack_confirmed
  if (filters.date_from || filters.date_to) {
    query.timestamp = {}
    if (filters.date_from) query.timestamp.$gte = filters.date_from
    if (filters.date_to) query.timestamp.$lte = filters.date_to
  }

  const skip = (page - 1) * limit

  // Use aggregation to join with security_analysis collection
  const pipeline = [
    { $match: query },
    { $sort: { timestamp: -1 } },
    { $skip: skip },
    { $limit: limit },
    {
      $lookup: {
        from: "security_analysis",
        localField: "event_id",
        foreignField: "event_id",
        as: "analysis",
      },
    },
    {
      $addFields: {
        analysis: { $arrayElemAt: ["$analysis", 0] },
      },
    },
  ]

  const [events, total] = await Promise.all([
    eventsCollection.aggregate(pipeline).toArray(),
    eventsCollection.countDocuments(query),
  ])

  return { events, total }
}

export async function getRecentEventsWithAnalysis(
  limit = 5,
): Promise<(SecurityEvent & { analysis?: SecurityAnalysis })[]> {
  const db = await getDatabase()
  const eventsCollection = db.collection<SecurityEvent>("security_events")

  const pipeline = [
    { $sort: { timestamp: -1 } },
    { $limit: limit },
    {
      $lookup: {
        from: "security_analysis",
        localField: "event_id",
        foreignField: "event_id",
        as: "analysis",
      },
    },
    {
      $addFields: {
        analysis: { $arrayElemAt: ["$analysis", 0] },
      },
    },
  ]

  return await eventsCollection.aggregate(pipeline).toArray()
}
