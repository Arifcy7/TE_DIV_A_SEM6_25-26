import type { ObjectId } from "mongodb"

export interface SecurityEvent {
  _id?: ObjectId
  event_id: string
  raw_event_data: {
    event_type: string
    timestamp: string
    source_ip: string
    destination: string
    username?: string
    success?: boolean
    failure_count?: number
    payload?: string
    user_agent?: string
    anomaly_score: number
    session_id?: string
    detection_confidence: number
    historical_events?: Array<{
      timestamp: string
      source_ip: string
      failure_count?: number
      session_id?: string
    }>
    asset_criticality: "low" | "medium" | "high"
    remediation_action: string
    http_method?: string
    request_headers?: Record<string, any>
    response_code?: number
    malware_family?: string
    file_hash?: string
    file_path?: string
    quarantine_status?: string
    destination_ip?: string
    port?: number
    protocol?: string
    bytes_transferred?: number
    duration?: number
    traffic_pattern?: string
  }
  stored_timestamp: Date
  event_type: string
  source_ip: string
  destination: string
  username?: string
  timestamp: Date
  success?: boolean
  failure_count?: number
  anomaly_score: number
  detection_confidence: number
  asset_criticality: "low" | "medium" | "high"
  status: "pending_analysis" | "analyzed"
  analysis_id?: ObjectId
  analyzed_timestamp?: Date
  attack_confirmed?: boolean
  final_urgency?: "Low" | "Medium" | "High"
}

export interface SecurityAnalysis {
  _id?: ObjectId
  event_id: string
  analysis_result: {
    attack_confirmed: boolean
    reasoning: string
    recommended_actions: string[]
    urgency: "Low" | "Medium" | "High"
  }
  analysis_timestamp: Date
  source: "cache" | "llm"
  attack_confirmed: boolean
  urgency: "Low" | "Medium" | "High"
  recommended_actions: string[]
  reasoning: string
}

export interface DashboardStats {
  totalEvents: number
  highPriorityEvents24h: number
  analyzedEvents: number
  pendingEvents: number
  confirmedAttacks: number
}

export interface EventTypeDistribution {
  event_type: string
  count: number
}

export interface UrgencyDistribution {
  urgency: "Low" | "Medium" | "High"
  count: number
}

export interface TopSourceIP {
  source_ip: string
  count: number
}
