// Sample data seeding script
const { MongoClient, ObjectId } = require("mongodb")

const sampleEvents = [
  {
    event_id: "468cc02ad787735f4e25c5b7a26c235d",
    raw_event_data: {
      event_type: "brute_force_login_attempt",
      timestamp: "2025-08-31T13:55:12Z",
      source_ip: "203.0.113.45",
      destination: "login.corpplatform.com",
      username: "admin",
      success: false,
      failure_count: 25,
      payload: "password: !admin@123",
      user_agent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
      anomaly_score: 0.92,
      session_id: "xyzabc98765",
      detection_confidence: 0.98,
      historical_events: [
        {
          timestamp: "2025-08-31T13:54:05Z",
          source_ip: "203.0.113.45",
          failure_count: 15,
          session_id: "xyzabc98765",
        },
      ],
      asset_criticality: "high",
      remediation_action: "none",
    },
    stored_timestamp: new Date("2025-09-07T17:38:10.405Z"),
    event_type: "brute_force_login_attempt",
    source_ip: "203.0.113.45",
    destination: "login.corpplatform.com",
    username: "admin",
    timestamp: new Date("2025-08-31T13:55:12.000Z"),
    success: false,
    failure_count: 25,
    anomaly_score: 0.92,
    detection_confidence: 0.98,
    asset_criticality: "high",
    status: "analyzed",
    analysis_id: new ObjectId("68bdc3026b11b1f8dbca85fb"),
    analyzed_timestamp: new Date("2025-09-07T17:38:10.775Z"),
    attack_confirmed: true,
    final_urgency: "High",
  },
  {
    event_id: "sql_injection_001",
    raw_event_data: {
      event_type: "sql_injection_attempt",
      timestamp: "2025-09-07T14:22:33Z",
      source_ip: "192.168.1.100",
      destination: "api.company.com/users",
      payload: "'; DROP TABLE users; --",
      http_method: "POST",
      user_agent: "sqlmap/1.6.12",
      anomaly_score: 0.95,
      detection_confidence: 0.99,
      asset_criticality: "high",
      remediation_action: "blocked",
    },
    stored_timestamp: new Date(),
    event_type: "sql_injection_attempt",
    source_ip: "192.168.1.100",
    destination: "api.company.com/users",
    timestamp: new Date("2025-09-07T14:22:33Z"),
    anomaly_score: 0.95,
    detection_confidence: 0.99,
    asset_criticality: "high",
    status: "analyzed",
    attack_confirmed: true,
    final_urgency: "High",
  },
  {
    event_id: "malware_detection_001",
    raw_event_data: {
      event_type: "malware_detection",
      timestamp: "2025-09-07T12:15:44Z",
      source_ip: "internal_host_192.168.1.50",
      destination: "external_c2_server.com",
      malware_family: "TrojanHorse.Generic",
      file_hash: "sha256:abc123def456",
      file_path: "/tmp/suspicious_file.exe",
      quarantine_status: "quarantined",
      anomaly_score: 0.88,
      detection_confidence: 0.94,
      asset_criticality: "medium",
      remediation_action: "quarantined",
    },
    stored_timestamp: new Date(),
    event_type: "malware_detection",
    source_ip: "internal_host_192.168.1.50",
    destination: "external_c2_server.com",
    timestamp: new Date("2025-09-07T12:15:44Z"),
    anomaly_score: 0.88,
    detection_confidence: 0.94,
    asset_criticality: "medium",
    status: "analyzed",
    attack_confirmed: true,
    final_urgency: "Medium",
  },
]

const sampleAnalysis = [
  {
    event_id: "468cc02ad787735f4e25c5b7a26c235d",
    analysis_result: {
      attack_confirmed: true,
      reasoning:
        'The event exhibits classic characteristics of a brute‑force login attack: a single source IP (203.0.113.45) generated 25 consecutive failed login attempts against the privileged "admin" account within a short time window, and an earlier related event shows 15 additional failures from the same IP and session only a minute earlier. The anomaly_score (0.92) and detection_confidence (0.98) are both well above typical thresholds, indicating the detection engine is highly confident this pattern deviates from normal behavior.',
      recommended_actions: [
        "Immediately block or rate‑limit traffic from source IP 203.0.113.45 at the firewall/IPS.",
        "Enforce account lockout policy for the admin account (e.g., lock after 5 failed attempts for 30 minutes).",
        "Require multi‑factor authentication (MFA) for all privileged accounts, especially admin.",
        "Reset the admin password and ensure it meets strong complexity requirements.",
        "Conduct a forensic review of authentication logs for the past 24‑48 hours to identify any successful logins or lateral movement.",
      ],
      urgency: "High",
    },
    analysis_timestamp: new Date("2025-09-07T17:38:10.774Z"),
    source: "cache",
    attack_confirmed: true,
    urgency: "High",
    recommended_actions: [
      "Immediately block or rate‑limit traffic from source IP 203.0.113.45 at the firewall/IPS.",
      "Enforce account lockout policy for the admin account (e.g., lock after 5 failed attempts for 30 minutes).",
      "Require multi‑factor authentication (MFA) for all privileged accounts, especially admin.",
      "Reset the admin password and ensure it meets strong complexity requirements.",
      "Conduct a forensic review of authentication logs for the past 24‑48 hours to identify any successful logins or lateral movement.",
    ],
    reasoning:
      'The event exhibits classic characteristics of a brute‑force login attack: a single source IP (203.0.113.45) generated 25 consecutive failed login attempts against the privileged "admin" account within a short time window, and an earlier related event shows 15 additional failures from the same IP and session only a minute earlier. The anomaly_score (0.92) and detection_confidence (0.98) are both well above typical thresholds, indicating the detection engine is highly confident this pattern deviates from normal behavior.',
  },
]

async function seedData() {
  const client = new MongoClient(process.env.MONGODB_URI)

  try {
    await client.connect()
    const db = client.db(process.env.MONGODB_DATABASE || "security_events")

    // Insert sample events
    const eventsCollection = db.collection("security_events")
    await eventsCollection.deleteMany({}) // Clear existing data
    await eventsCollection.insertMany(sampleEvents)

    // Insert sample analysis
    const analysisCollection = db.collection("security_analysis")
    await analysisCollection.deleteMany({}) // Clear existing data
    await analysisCollection.insertMany(sampleAnalysis)

    console.log("Sample data seeded successfully")
  } catch (error) {
    console.error("Error seeding data:", error)
  } finally {
    await client.close()
  }
}

seedData()
