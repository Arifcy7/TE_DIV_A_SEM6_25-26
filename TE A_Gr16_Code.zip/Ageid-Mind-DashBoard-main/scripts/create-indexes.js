// MongoDB index creation script
const { MongoClient } = require("mongodb")

async function createIndexes() {
  const client = new MongoClient(process.env.MONGODB_URI)

  try {
    await client.connect()
    const db = client.db(process.env.MONGODB_DATABASE || "security_events")

    // Security events collection indexes
    const eventsCollection = db.collection("security_events")
    await eventsCollection.createIndex({ event_id: 1 }, { unique: true })
    await eventsCollection.createIndex({ timestamp: -1 })
    await eventsCollection.createIndex({ source_ip: 1 })
    await eventsCollection.createIndex({ event_type: 1 })
    await eventsCollection.createIndex({ status: 1 })
    await eventsCollection.createIndex({ final_urgency: 1 })
    await eventsCollection.createIndex({ attack_confirmed: 1 })

    // Security analysis collection indexes
    const analysisCollection = db.collection("security_analysis")
    await analysisCollection.createIndex({ event_id: 1 })
    await analysisCollection.createIndex({ analysis_timestamp: -1 })
    await analysisCollection.createIndex({ urgency: 1 })
    await analysisCollection.createIndex({ attack_confirmed: 1 })

    console.log("Indexes created successfully")
  } catch (error) {
    console.error("Error creating indexes:", error)
  } finally {
    await client.close()
  }
}

createIndexes()
