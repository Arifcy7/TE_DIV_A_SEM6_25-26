"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { formatDistanceToNow } from "date-fns"
import Link from "next/link"
import { Brain } from "lucide-react"
import type { SecurityEvent, SecurityAnalysis } from "@/lib/types"

interface RecentEventsProps {
  events: (SecurityEvent & { analysis?: SecurityAnalysis })[]
}

const urgencyColors = {
  High: "destructive",
  Medium: "secondary",
  Low: "outline",
} as const

const eventTypeColors = {
  brute_force_login_attempt: "destructive",
  sql_injection_attempt: "destructive",
  malware_detection: "secondary",
  suspicious_network_traffic: "outline",
} as const

export function RecentEvents({ events }: RecentEventsProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Security Events</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {events.map((event) => (
            <div
              key={event._id?.toString()}
              className="flex items-center justify-between border-b pb-4 last:border-b-0"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <Badge variant={eventTypeColors[event.event_type as keyof typeof eventTypeColors] || "outline"}>
                    {event.event_type.replace(/_/g, " ")}
                  </Badge>
                  {event.final_urgency && (
                    <Badge variant={urgencyColors[event.final_urgency as keyof typeof urgencyColors]}>
                      {event.final_urgency}
                    </Badge>
                  )}
                  {event.attack_confirmed && <Badge variant="destructive">Confirmed Attack</Badge>}
                  {event.analysis && (
                    <Badge variant="secondary">
                      <Brain className="mr-1 h-3 w-3" />
                      AI Analyzed
                    </Badge>
                  )}
                </div>
                <p className="text-sm text-muted-foreground">
                  <span className="font-medium">Source:</span> {event.source_ip} → {event.destination}
                </p>
                {event.username && (
                  <p className="text-sm text-muted-foreground">
                    <span className="font-medium">Target:</span> {event.username}
                  </p>
                )}
                {event.analysis && (
                  <p className="text-xs text-blue-600 dark:text-blue-400">
                    {event.analysis.recommended_actions.length} AI recommendations available
                  </p>
                )}
              </div>
              <div className="text-right">
                <p className="text-sm text-muted-foreground">
                  {formatDistanceToNow(new Date(event.timestamp), { addSuffix: true })}
                </p>
                <Link href={`/events/${event._id}`} className="text-sm text-primary hover:underline">
                  View Details
                </Link>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
