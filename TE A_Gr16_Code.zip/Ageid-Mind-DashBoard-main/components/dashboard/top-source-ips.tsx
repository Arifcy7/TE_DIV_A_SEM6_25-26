"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import type { TopSourceIP } from "@/lib/types"

interface TopSourceIPsProps {
  data: TopSourceIP[]
}

export function TopSourceIPs({ data }: TopSourceIPsProps) {
  const maxCount = Math.max(...data.map((item) => item.count))

  return (
    <Card>
      <CardHeader>
        <CardTitle>Top Source IPs</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {data.map((item, index) => (
            <div key={item.source_ip} className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">{item.source_ip}</span>
                <span className="text-sm text-muted-foreground">{item.count} events</span>
              </div>
              <Progress value={(item.count / maxCount) * 100} className="h-2" />
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
