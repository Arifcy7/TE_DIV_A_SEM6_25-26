"use client"

import { PieChart, Pie, Cell } from "recharts"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import type { UrgencyDistribution } from "@/lib/types"

interface UrgencyPieChartProps {
  data: UrgencyDistribution[]
}

const COLORS = {
  High: "hsl(var(--destructive))",
  Medium: "hsl(var(--chart-3))",
  Low: "hsl(var(--chart-2))",
}

const chartConfig = {
  High: {
    label: "High Priority",
    color: "hsl(var(--destructive))",
  },
  Medium: {
    label: "Medium Priority",
    color: "hsl(var(--chart-3))",
  },
  Low: {
    label: "Low Priority",
    color: "hsl(var(--chart-2))",
  },
}

export function UrgencyPieChart({ data }: UrgencyPieChartProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Urgency Distribution</CardTitle>
      </CardHeader>
      <CardContent>
        <ChartContainer config={chartConfig} className="h-[300px]">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              labelLine={false}
              label={({ urgency, percent }) => `${urgency} ${(percent * 100).toFixed(0)}%`}
              outerRadius={80}
              fill="#8884d8"
              dataKey="count"
              nameKey="urgency"
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[entry.urgency as keyof typeof COLORS]} />
              ))}
            </Pie>
            <ChartTooltip content={<ChartTooltipContent />} />
          </PieChart>
        </ChartContainer>
      </CardContent>
    </Card>
  )
}
