"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Shield, AlertTriangle, CheckCircle, Activity } from "lucide-react"
import type { DashboardStats } from "@/lib/types"

interface StatsCardsProps {
  stats: DashboardStats
}

export function StatsCards({ stats }: StatsCardsProps) {
  const cards = [
    {
      title: "Total Events",
      value: stats.totalEvents.toLocaleString(),
      icon: Activity,
      description: "All security events",
    },
    {
      title: "High Priority (24h)",
      value: stats.highPriorityEvents24h.toLocaleString(),
      icon: AlertTriangle,
      description: "Critical events today",
      className: "text-destructive",
    },
    {
      title: "Analyzed Events",
      value: stats.analyzedEvents.toLocaleString(),
      icon: CheckCircle,
      description: `${stats.pendingEvents} pending analysis`,
      className: "text-green-600",
    },
    {
      title: "Confirmed Attacks",
      value: stats.confirmedAttacks.toLocaleString(),
      icon: Shield,
      description: "Verified threats",
      className: "text-destructive",
    },
  ]

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {cards.map((card) => {
        const Icon = card.icon
        return (
          <Card key={card.title}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{card.title}</CardTitle>
              <Icon className={cn("h-4 w-4", card.className)} />
            </CardHeader>
            <CardContent>
              <div className={cn("text-2xl font-bold", card.className)}>{card.value}</div>
              <p className="text-xs text-muted-foreground">{card.description}</p>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}

function cn(...classes: (string | undefined)[]): string {
  return classes.filter(Boolean).join(" ")
}
