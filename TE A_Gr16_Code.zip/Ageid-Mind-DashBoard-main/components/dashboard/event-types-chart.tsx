"use client"

import { BarChart, Bar, XAxis, YAxis, CartesianGrid } from "recharts"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import type { EventTypeDistribution } from "@/lib/types"

interface EventTypesChartProps {
  data: EventTypeDistribution[]
}

const chartConfig = {
  count: {
    label: "Event Count",
    color: "hsl(var(--chart-1))",
  },
}

export function EventTypesChart({ data }: EventTypesChartProps) {
  // Format event type names for better display
  const formattedData = data.map((item) => ({
    ...item,
    event_type_display: item.event_type.replace(/_/g, " ").replace(/\b\w/g, (l) => l.toUpperCase()),
  }))

  return (
    <Card>
      <CardHeader>
        <CardTitle>Event Types Distribution</CardTitle>
      </CardHeader>
      <CardContent>
        <ChartContainer config={chartConfig} className="h-[300px]">
          <BarChart data={formattedData} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="event_type_display" angle={-45} textAnchor="end" height={80} fontSize={12} />
            <YAxis />
            <ChartTooltip content={<ChartTooltipContent />} />
            <Bar dataKey="count" fill="var(--color-count)" />
          </BarChart>
        </ChartContainer>
      </CardContent>
    </Card>
  )
}
