"use client"

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
} from "recharts"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { Activity, Clock } from "lucide-react"

interface CorrelationChartsProps {
  data: {
    criticalityCorrelation: Array<{
      assetCriticality: string
      High: number
      Medium: number
      Low: number
      total: number
    }>
    timePatterns: Array<{
      hour: number
      High: number
      Medium: number
      Low: number
      total: number
    }>
  }
}

const chartConfig = {
  High: {
    label: "High Priority",
    color: "hsl(var(--destructive))",
  },
  Medium: {
    label: "Medium Priority",
    color: "hsl(var(--chart-3))",
  },
  Low: {
    label: "Low Priority",
    color: "hsl(var(--chart-2))",
  },
  total: {
    label: "Total Events",
    color: "hsl(var(--chart-1))",
  },
}

export function CorrelationCharts({ data }: CorrelationChartsProps) {
  // Format time patterns for radar chart
  const radarData = data.timePatterns.map((item) => ({
    hour: `${item.hour}:00`,
    value: item.total,
    High: item.High,
    Medium: item.Medium,
    Low: item.Low,
  }))

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      {/* Asset Criticality vs Attack Frequency */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Asset Criticality vs Attack Frequency
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ChartContainer config={chartConfig} className="h-[300px]">
            <BarChart data={data.criticalityCorrelation} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="assetCriticality" />
              <YAxis />
              <ChartTooltip content={<ChartTooltipContent />} />
              <Bar dataKey="High" stackId="a" fill="var(--color-High)" />
              <Bar dataKey="Medium" stackId="a" fill="var(--color-Medium)" />
              <Bar dataKey="Low" stackId="a" fill="var(--color-Low)" />
            </BarChart>
          </ChartContainer>
        </CardContent>
      </Card>

      {/* Time-based Attack Patterns */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Attack Patterns by Hour
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ChartContainer config={chartConfig} className="h-[300px]">
            <RadarChart data={radarData} margin={{ top: 20, right: 30, bottom: 20, left: 30 }}>
              <PolarGrid />
              <PolarAngleAxis dataKey="hour" fontSize={10} />
              <PolarRadiusAxis angle={90} domain={[0, "dataMax"]} fontSize={10} />
              <Radar
                name="Total Events"
                dataKey="value"
                stroke="var(--color-total)"
                fill="var(--color-total)"
                fillOpacity={0.1}
                strokeWidth={2}
              />
              <ChartTooltip content={<ChartTooltipContent />} />
            </RadarChart>
          </ChartContainer>
        </CardContent>
      </Card>
    </div>
  )
}
