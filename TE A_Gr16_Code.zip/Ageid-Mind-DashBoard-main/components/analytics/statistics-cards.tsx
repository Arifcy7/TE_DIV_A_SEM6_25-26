"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { BarChart, Clock, Shield, TrendingDown } from "lucide-react"

interface StatisticsCardsProps {
  statistics: {
    overview: {
      totalEvents: number
      analyzedEvents: number
      confirmedAttacks: number
      falsePositiveRate: number
      avgAnalysisTimeMinutes: number
    }
  }
}

export function StatisticsCards({ statistics }: StatisticsCardsProps) {
  const { overview } = statistics

  const analysisRate = overview.totalEvents > 0 ? (overview.analyzedEvents / overview.totalEvents) * 100 : 0
  const attackRate = overview.totalEvents > 0 ? (overview.confirmedAttacks / overview.totalEvents) * 100 : 0

  const cards = [
    {
      title: "Analysis Coverage",
      value: `${Math.round(analysisRate)}%`,
      description: `${overview.analyzedEvents} of ${overview.totalEvents} events analyzed`,
      icon: BarChart,
      progress: analysisRate,
      color: analysisRate > 90 ? "text-green-600" : analysisRate > 70 ? "text-yellow-600" : "text-destructive",
    },
    {
      title: "Attack Confirmation Rate",
      value: `${Math.round(attackRate)}%`,
      description: `${overview.confirmedAttacks} confirmed attacks`,
      icon: Shield,
      progress: attackRate,
      color: "text-destructive",
    },
    {
      title: "False Positive Rate",
      value: `${overview.falsePositiveRate}%`,
      description: "Lower is better",
      icon: TrendingDown,
      progress: overview.falsePositiveRate,
      color:
        overview.falsePositiveRate < 10
          ? "text-green-600"
          : overview.falsePositiveRate < 25
            ? "text-yellow-600"
            : "text-destructive",
    },
    {
      title: "Avg Analysis Time",
      value: `${overview.avgAnalysisTimeMinutes}m`,
      description: "Time to complete analysis",
      icon: Clock,
      progress: Math.min((overview.avgAnalysisTimeMinutes / 60) * 100, 100), // Normalize to 60 minutes max
      color:
        overview.avgAnalysisTimeMinutes < 15
          ? "text-green-600"
          : overview.avgAnalysisTimeMinutes < 30
            ? "text-yellow-600"
            : "text-destructive",
    },
  ]

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {cards.map((card) => {
        const Icon = card.icon
        return (
          <Card key={card.title}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{card.title}</CardTitle>
              <Icon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${card.color}`}>{card.value}</div>
              <p className="text-xs text-muted-foreground mb-2">{card.description}</p>
              <Progress value={card.progress} className="h-2" />
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}
