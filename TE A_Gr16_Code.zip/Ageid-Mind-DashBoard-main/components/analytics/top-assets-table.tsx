"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Target } from "lucide-react"

interface TopAssetsTableProps {
  assets: Array<{
    asset: string
    totalEvents: number
    highPriorityEvents: number
    riskScore: number
  }>
}

export function TopAssetsTable({ assets }: TopAssetsTableProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Target className="h-5 w-5" />
          Top Targeted Assets
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Asset</TableHead>
              <TableHead className="text-right">Total Events</TableHead>
              <TableHead className="text-right">High Priority</TableHead>
              <TableHead className="text-right">Risk Score</TableHead>
              <TableHead>Risk Level</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {assets.map((asset, index) => (
              <TableRow key={asset.asset}>
                <TableCell className="font-mono text-sm">{asset.asset}</TableCell>
                <TableCell className="text-right">{asset.totalEvents}</TableCell>
                <TableCell className="text-right">{asset.highPriorityEvents}</TableCell>
                <TableCell className="text-right">{asset.riskScore}%</TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Badge
                      variant={asset.riskScore >= 75 ? "destructive" : asset.riskScore >= 50 ? "secondary" : "outline"}
                    >
                      {asset.riskScore >= 75 ? "High" : asset.riskScore >= 50 ? "Medium" : "Low"}
                    </Badge>
                    <Progress value={asset.riskScore} className="h-2 w-16" />
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}
