"use client"

import { LineChart, Line, XAxis, YAxis, CartesianGrid, Legend } from "recharts"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { TrendingUp } from "lucide-react"

interface TrendsChartProps {
  data: Array<{
    date: string
    High: number
    Medium: number
    Low: number
    total: number
  }>
  timeRange: string
  onTimeRangeChange: (range: string) => void
}

const chartConfig = {
  High: {
    label: "High Priority",
    color: "hsl(var(--destructive))",
  },
  Medium: {
    label: "Medium Priority",
    color: "hsl(var(--chart-3))",
  },
  Low: {
    label: "Low Priority",
    color: "hsl(var(--chart-2))",
  },
  total: {
    label: "Total Events",
    color: "hsl(var(--chart-1))",
  },
}

export function TrendsChart({ data, timeRange, onTimeRangeChange }: TrendsChartProps) {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Attack Trends Over Time
          </CardTitle>
          <Select value={timeRange} onValueChange={onTimeRangeChange}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="24h">Last 24h</SelectItem>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
              <SelectItem value="90d">Last 90 days</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent>
        <ChartContainer config={chartConfig} className="h-[400px]">
          <LineChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis
              dataKey="date"
              fontSize={12}
              tickFormatter={(value) => {
                const date = new Date(value)
                if (timeRange === "24h") {
                  return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
                }
                return date.toLocaleDateString([], { month: "short", day: "numeric" })
              }}
            />
            <YAxis fontSize={12} />
            <ChartTooltip content={<ChartTooltipContent />} />
            <Legend />
            <Line type="monotone" dataKey="High" stroke="var(--color-High)" strokeWidth={2} dot={{ r: 4 }} />
            <Line type="monotone" dataKey="Medium" stroke="var(--color-Medium)" strokeWidth={2} dot={{ r: 4 }} />
            <Line type="monotone" dataKey="Low" stroke="var(--color-Low)" strokeWidth={2} dot={{ r: 4 }} />
          </LineChart>
        </ChartContainer>
      </CardContent>
    </Card>
  )
}
