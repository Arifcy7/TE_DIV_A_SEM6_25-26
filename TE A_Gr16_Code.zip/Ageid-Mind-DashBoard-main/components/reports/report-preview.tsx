"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Download, Eye, Calendar } from "lucide-react"
import { format } from "date-fns"

interface ReportPreviewProps {
  reportData: any
  metadata: {
    reportType: string
    dateRange: string
    startDate: string
    endDate: string
    generatedAt: string
    format: string
  }
  onDownload: () => void
}

export function ReportPreview({ reportData, metadata, onDownload }: ReportPreviewProps) {
  const getReportTitle = (type: string) => {
    switch (type) {
      case "security_summary":
        return "Security Summary Report"
      case "incident_report":
        return "Incident Report"
      case "trend_analysis":
        return "Trend Analysis Report"
      case "executive_summary":
        return "Executive Summary"
      default:
        return "Security Report"
    }
  }

  const renderSecuritySummary = (data: any) => (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-4">
        <div className="text-center">
          <div className="text-2xl font-bold">{data.overview.totalEvents}</div>
          <div className="text-sm text-muted-foreground">Total Events</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-destructive">{data.overview.highPriorityEvents}</div>
          <div className="text-sm text-muted-foreground">High Priority</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-destructive">{data.overview.confirmedAttacks}</div>
          <div className="text-sm text-muted-foreground">Confirmed Attacks</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold">{data.overview.falsePositiveRate.toFixed(1)}%</div>
          <div className="text-sm text-muted-foreground">False Positive Rate</div>
        </div>
      </div>

      <div>
        <h4 className="font-semibold mb-3">Events by Type</h4>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Event Type</TableHead>
              <TableHead className="text-right">Count</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {data.eventsByType.map((item: any, index: number) => (
              <TableRow key={index}>
                <TableCell>{item._id.replace(/_/g, " ")}</TableCell>
                <TableCell className="text-right">{item.count}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )

  const renderIncidentReport = (data: any) => (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-3">
        <div className="text-center">
          <div className="text-2xl font-bold text-destructive">{data.totalIncidents}</div>
          <div className="text-sm text-muted-foreground">Total Incidents</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-destructive">{data.highPriorityIncidents}</div>
          <div className="text-sm text-muted-foreground">High Priority</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold">
            {data.totalIncidents > 0 ? ((data.highPriorityIncidents / data.totalIncidents) * 100).toFixed(0) : 0}%
          </div>
          <div className="text-sm text-muted-foreground">Critical Rate</div>
        </div>
      </div>

      <div>
        <h4 className="font-semibold mb-3">Recent Incidents</h4>
        <div className="space-y-3">
          {data.incidents.slice(0, 5).map((incident: any, index: number) => (
            <div key={index} className="border rounded-lg p-4">
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Badge variant="destructive">{incident.event_type.replace(/_/g, " ")}</Badge>
                  <Badge variant={incident.final_urgency === "High" ? "destructive" : "secondary"}>
                    {incident.final_urgency}
                  </Badge>
                </div>
                <span className="text-sm text-muted-foreground">
                  {format(new Date(incident.timestamp), "MMM dd, HH:mm")}
                </span>
              </div>
              <div className="text-sm">
                <span className="font-medium">Source:</span> {incident.source_ip} → {incident.destination}
              </div>
              {incident.analysis && (
                <div className="mt-2 text-sm text-muted-foreground">
                  {incident.analysis.reasoning.substring(0, 150)}...
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  )

  const renderExecutiveSummary = (data: any) => (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-4">
        <div className="text-center">
          <div className="text-2xl font-bold">{data.keyMetrics.totalEvents}</div>
          <div className="text-sm text-muted-foreground">Total Events</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-destructive">{data.keyMetrics.confirmedAttacks}</div>
          <div className="text-sm text-muted-foreground">Confirmed Attacks</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-destructive">{data.keyMetrics.highPriorityEvents}</div>
          <div className="text-sm text-muted-foreground">High Priority</div>
        </div>
        <div className="text-center">
          <Badge
            variant={
              data.keyMetrics.threatLevel === "High"
                ? "destructive"
                : data.keyMetrics.threatLevel === "Medium"
                  ? "secondary"
                  : "outline"
            }
            className="text-lg px-3 py-1"
          >
            {data.keyMetrics.threatLevel}
          </Badge>
          <div className="text-sm text-muted-foreground mt-1">Threat Level</div>
        </div>
      </div>

      <div>
        <h4 className="font-semibold mb-3">Key Recommendations</h4>
        <ul className="space-y-2">
          {data.recommendations.map((rec: string, index: number) => (
            <li key={index} className="flex items-start gap-2">
              <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0" />
              <span className="text-sm">{rec}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  )

  const renderReportContent = () => {
    switch (metadata.reportType) {
      case "security_summary":
        return renderSecuritySummary(reportData)
      case "incident_report":
        return renderIncidentReport(reportData)
      case "executive_summary":
        return renderExecutiveSummary(reportData)
      default:
        return (
          <pre className="bg-muted p-4 rounded-md text-xs overflow-x-auto">{JSON.stringify(reportData, null, 2)}</pre>
        )
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Eye className="h-5 w-5" />
              {getReportTitle(metadata.reportType)}
            </CardTitle>
            <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
              <div className="flex items-center gap-1">
                <Calendar className="h-4 w-4" />
                {format(new Date(metadata.startDate), "MMM dd")} - {format(new Date(metadata.endDate), "MMM dd, yyyy")}
              </div>
              <div>Generated: {format(new Date(metadata.generatedAt), "MMM dd, yyyy HH:mm")}</div>
            </div>
          </div>
          <Button onClick={onDownload} className="flex items-center gap-2">
            <Download className="h-4 w-4" />
            Download {metadata.format.toUpperCase()}
          </Button>
        </div>
      </CardHeader>
      <CardContent>{renderReportContent()}</CardContent>
    </Card>
  )
}
