"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { FileText, Settings } from "lucide-react"

interface ReportGeneratorProps {
  onGenerateReport: (config: ReportConfig) => void
  isGenerating: boolean
}

export interface ReportConfig {
  reportType: string
  dateRange: string
  format: string
}

const reportTypes = [
  { value: "security_summary", label: "Security Summary", description: "Overview of security events and metrics" },
  { value: "incident_report", label: "Incident Report", description: "Detailed analysis of confirmed attacks" },
  { value: "trend_analysis", label: "Trend Analysis", description: "Historical patterns and trends" },
  { value: "executive_summary", label: "Executive Summary", description: "High-level overview for leadership" },
]

const dateRanges = [
  { value: "today", label: "Today" },
  { value: "yesterday", label: "Yesterday" },
  { value: "week", label: "Last 7 Days" },
  { value: "month", label: "This Month" },
  { value: "quarter", label: "This Quarter" },
]

const formats = [
  { value: "json", label: "JSON", description: "Machine-readable format" },
  { value: "pdf", label: "PDF", description: "Formatted document (coming soon)" },
  { value: "csv", label: "CSV", description: "Spreadsheet format (coming soon)" },
]

export function ReportGenerator({ onGenerateReport, isGenerating }: ReportGeneratorProps) {
  const [reportType, setReportType] = useState("")
  const [dateRange, setDateRange] = useState("")
  const [format, setFormat] = useState("json")

  const handleGenerate = () => {
    if (reportType && dateRange) {
      onGenerateReport({ reportType, dateRange, format })
    }
  }

  const canGenerate = reportType && dateRange && !isGenerating

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Settings className="h-5 w-5" />
          Generate Report
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Report Type Selection */}
        <div className="space-y-2">
          <Label htmlFor="reportType">Report Type</Label>
          <Select value={reportType} onValueChange={setReportType}>
            <SelectTrigger>
              <SelectValue placeholder="Select report type" />
            </SelectTrigger>
            <SelectContent>
              {reportTypes.map((type) => (
                <SelectItem key={type.value} value={type.value}>
                  <div>
                    <div className="font-medium">{type.label}</div>
                    <div className="text-xs text-muted-foreground">{type.description}</div>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Date Range Selection */}
        <div className="space-y-2">
          <Label htmlFor="dateRange">Date Range</Label>
          <Select value={dateRange} onValueChange={setDateRange}>
            <SelectTrigger>
              <SelectValue placeholder="Select date range" />
            </SelectTrigger>
            <SelectContent>
              {dateRanges.map((range) => (
                <SelectItem key={range.value} value={range.value}>
                  {range.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Format Selection */}
        <div className="space-y-2">
          <Label htmlFor="format">Export Format</Label>
          <Select value={format} onValueChange={setFormat}>
            <SelectTrigger>
              <SelectValue placeholder="Select format" />
            </SelectTrigger>
            <SelectContent>
              {formats.map((fmt) => (
                <SelectItem key={fmt.value} value={fmt.value} disabled={fmt.value !== "json"}>
                  <div className="flex items-center gap-2">
                    <span>{fmt.label}</span>
                    {fmt.value !== "json" && <Badge variant="outline">Coming Soon</Badge>}
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Generate Button */}
        <Button onClick={handleGenerate} disabled={!canGenerate} className="w-full">
          {isGenerating ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
              Generating Report...
            </>
          ) : (
            <>
              <FileText className="mr-2 h-4 w-4" />
              Generate Report
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  )
}
