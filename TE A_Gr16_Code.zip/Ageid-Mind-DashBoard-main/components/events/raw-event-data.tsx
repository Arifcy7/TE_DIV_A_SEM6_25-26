"use client"

import type React from "react"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { ChevronDown, ChevronRight, Clock, Code, FileText } from "lucide-react"
import { useState } from "react"
import { format } from "date-fns"
import type { SecurityEvent } from "@/lib/types"

interface RawEventDataProps {
  event: SecurityEvent
}

export function RawEventData({ event }: RawEventDataProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [showRawJson, setShowRawJson] = useState(false)

  const renderValue = (key: string, value: any): React.ReactNode => {
    if (value === null || value === undefined) return <span className="text-muted-foreground">null</span>
    if (typeof value === "boolean") return <Badge variant={value ? "default" : "outline"}>{String(value)}</Badge>
    if (typeof value === "number") return <span className="font-mono">{value}</span>
    if (typeof value === "string") {
      if (key.includes("timestamp") || key.includes("time")) {
        try {
          return <span className="font-mono text-sm">{format(new Date(value), "MMM dd, yyyy HH:mm:ss")}</span>
        } catch {
          return <span className="font-mono text-sm">{value}</span>
        }
      }
      return <span className="font-mono text-sm break-all">{value}</span>
    }
    if (Array.isArray(value)) {
      return (
        <div className="space-y-2">
          {value.map((item, index) => (
            <div key={index} className="border-l-2 border-muted pl-3">
              {typeof item === "object" ? (
                <div className="space-y-1">
                  {Object.entries(item).map(([k, v]) => (
                    <div key={k} className="flex gap-2 text-sm">
                      <span className="font-medium text-muted-foreground min-w-0 flex-shrink-0">{k}:</span>
                      <span className="min-w-0 flex-1">{renderValue(k, v)}</span>
                    </div>
                  ))}
                </div>
              ) : (
                renderValue(`item_${index}`, item)
              )}
            </div>
          ))}
        </div>
      )
    }
    if (typeof value === "object") {
      return (
        <div className="space-y-2 border-l-2 border-muted pl-3">
          {Object.entries(value).map(([k, v]) => (
            <div key={k} className="flex gap-2 text-sm">
              <span className="font-medium text-muted-foreground min-w-0 flex-shrink-0">{k}:</span>
              <span className="min-w-0 flex-1">{renderValue(k, v)}</span>
            </div>
          ))}
        </div>
      )
    }
    return <span>{String(value)}</span>
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Raw Event Data
          </CardTitle>
          <div className="flex gap-2">
            <button
              onClick={() => setShowRawJson(!showRawJson)}
              className="text-sm text-muted-foreground hover:text-foreground flex items-center gap-1"
            >
              <Code className="h-4 w-4" />
              {showRawJson ? "Formatted View" : "Raw JSON"}
            </button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {showRawJson ? (
          <pre className="bg-muted p-4 rounded-md text-xs overflow-x-auto">
            {JSON.stringify(event.raw_event_data, null, 2)}
          </pre>
        ) : (
          <div className="space-y-4">
            {Object.entries(event.raw_event_data).map(([key, value]) => (
              <div key={key}>
                {key === "historical_events" && Array.isArray(value) && value.length > 0 ? (
                  <Collapsible open={isOpen} onOpenChange={setIsOpen}>
                    <CollapsibleTrigger className="flex items-center gap-2 text-sm font-medium hover:text-foreground">
                      {isOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                      <Clock className="h-4 w-4" />
                      Historical Events ({value.length})
                    </CollapsibleTrigger>
                    <CollapsibleContent className="mt-2">
                      <div className="space-y-3 border-l-2 border-muted pl-4">
                        {value.map((event, index) => (
                          <div key={index} className="bg-muted/50 p-3 rounded-md">
                            <div className="space-y-1">
                              {Object.entries(event).map(([k, v]) => (
                                <div key={k} className="flex gap-2 text-sm">
                                  <span className="font-medium text-muted-foreground min-w-0 flex-shrink-0">{k}:</span>
                                  <span className="min-w-0 flex-1">{renderValue(k, v)}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    </CollapsibleContent>
                  </Collapsible>
                ) : (
                  <div className="flex gap-2 text-sm">
                    <span className="font-medium text-muted-foreground min-w-0 flex-shrink-0">{key}:</span>
                    <span className="min-w-0 flex-1">{renderValue(key, value)}</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
