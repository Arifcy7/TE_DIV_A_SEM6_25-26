"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Shield, AlertTriangle, Clock, Target, User, Globe, Hash } from "lucide-react"
import { format, formatDistanceToNow } from "date-fns"
import Link from "next/link"
import type { SecurityEvent } from "@/lib/types"

interface EventDetailsHeaderProps {
  event: SecurityEvent
}

const urgencyColors = {
  High: "destructive",
  Medium: "secondary",
  Low: "outline",
} as const

const eventTypeColors = {
  brute_force_login_attempt: "destructive",
  sql_injection_attempt: "destructive",
  malware_detection: "secondary",
  suspicious_network_traffic: "outline",
} as const

export function EventDetailsHeader({ event }: EventDetailsHeaderProps) {
  const urgencyColor = event.final_urgency
    ? urgencyColors[event.final_urgency as keyof typeof urgencyColors]
    : "outline"

  const eventTypeColor = eventTypeColors[event.event_type as keyof typeof eventTypeColors] || "outline"

  return (
    <div className="space-y-6">
      {/* Back button and title */}
      <div className="flex items-center gap-4">
        <Link href="/events">
          <Button variant="outline" size="sm">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Events
          </Button>
        </Link>
        <div>
          <h1 className="text-3xl font-bold text-foreground">Security Event Details</h1>
          <p className="text-muted-foreground">Event ID: {event.event_id}</p>
        </div>
      </div>

      {/* Event overview card */}
      <Card>
        <CardHeader>
          <div className="flex items-start justify-between">
            <CardTitle className="text-xl">Event Overview</CardTitle>
            <div className="flex flex-wrap gap-2">
              <Badge variant={eventTypeColor}>{event.event_type.replace(/_/g, " ")}</Badge>
              {event.final_urgency && (
                <Badge variant={urgencyColor}>
                  <AlertTriangle className="mr-1 h-3 w-3" />
                  {event.final_urgency} Priority
                </Badge>
              )}
              {event.attack_confirmed && (
                <Badge variant="destructive">
                  <Shield className="mr-1 h-3 w-3" />
                  Confirmed Attack
                </Badge>
              )}
              <Badge variant="outline">{event.status === "analyzed" ? "Analyzed" : "Pending Analysis"}</Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Target className="h-4 w-4 text-muted-foreground" />
                <span className="font-medium">Source IP:</span>
                <span className="font-mono text-sm">{event.source_ip}</span>
              </div>
              <div className="flex items-center gap-2">
                <Globe className="h-4 w-4 text-muted-foreground" />
                <span className="font-medium">Destination:</span>
                <span className="font-mono text-sm">{event.destination}</span>
              </div>
              {event.username && (
                <div className="flex items-center gap-2">
                  <User className="h-4 w-4 text-muted-foreground" />
                  <span className="font-medium">Target User:</span>
                  <span className="font-mono text-sm">{event.username}</span>
                </div>
              )}
              <div className="flex items-center gap-2">
                <Hash className="h-4 w-4 text-muted-foreground" />
                <span className="font-medium">Asset Criticality:</span>
                <Badge
                  variant={
                    event.asset_criticality === "high"
                      ? "destructive"
                      : event.asset_criticality === "medium"
                        ? "secondary"
                        : "outline"
                  }
                >
                  {event.asset_criticality}
                </Badge>
              </div>
            </div>
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <span className="font-medium">Event Time:</span>
                <span className="text-sm">{format(new Date(event.timestamp), "MMM dd, yyyy HH:mm:ss")}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <span className="font-medium">Stored:</span>
                <span className="text-sm">
                  {formatDistanceToNow(new Date(event.stored_timestamp), { addSuffix: true })}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-medium">Anomaly Score:</span>
                <span
                  className={`font-mono text-sm ${event.anomaly_score > 0.8 ? "text-destructive" : event.anomaly_score > 0.5 ? "text-yellow-600" : "text-green-600"}`}
                >
                  {(event.anomaly_score * 100).toFixed(1)}%
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-medium">Detection Confidence:</span>
                <span className="font-mono text-sm">{(event.detection_confidence * 100).toFixed(1)}%</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
