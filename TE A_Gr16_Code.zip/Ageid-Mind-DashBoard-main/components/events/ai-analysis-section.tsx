"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Brain, CheckCircle, Clock, Lightbulb, AlertTriangle } from "lucide-react"
import { format } from "date-fns"
import type { SecurityAnalysis } from "@/lib/types"

interface AIAnalysisSectionProps {
  analysis: SecurityAnalysis | null
}

export function AIAnalysisSection({ analysis }: AIAnalysisSectionProps) {
  if (!analysis) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5" />
            AI Analysis
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center h-32 text-muted-foreground">
            <div className="text-center">
              <AlertTriangle className="h-8 w-8 mx-auto mb-2" />
              <p>No AI analysis available for this event</p>
              <p className="text-sm">Analysis may still be in progress</p>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  const urgencyColor =
    analysis.urgency === "High" ? "destructive" : analysis.urgency === "Medium" ? "secondary" : "outline"

  return (
    <div className="space-y-6">
      {/* Analysis Overview */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Brain className="h-5 w-5" />
              AI Analysis Results
            </CardTitle>
            <div className="flex items-center gap-2">
              <Badge variant={analysis.attack_confirmed ? "destructive" : "outline"}>
                {analysis.attack_confirmed ? "Attack Confirmed" : "Not Confirmed"}
              </Badge>
              <Badge variant={urgencyColor}>
                <AlertTriangle className="mr-1 h-3 w-3" />
                {analysis.urgency} Priority
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Clock className="h-4 w-4" />
              <span>Analyzed: {format(new Date(analysis.analysis_timestamp), "MMM dd, yyyy HH:mm:ss")}</span>
              <Badge variant="outline" className="ml-2">
                Source: {analysis.source === "cache" ? "Cached Result" : "Live AI Analysis"}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Reasoning */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lightbulb className="h-5 w-5" />
            Analysis Reasoning
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="prose prose-sm max-w-none">
            <p className="text-sm leading-relaxed whitespace-pre-wrap">{analysis.reasoning}</p>
          </div>
        </CardContent>
      </Card>

      {/* Recommended Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5" />
            Recommended Actions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {analysis.recommended_actions.map((action, index) => (
              <div key={index} className="flex items-start gap-3 p-3 bg-muted/50 rounded-md">
                <Checkbox id={`action-${index}`} className="mt-0.5" />
                <label htmlFor={`action-${index}`} className="text-sm leading-relaxed cursor-pointer flex-1">
                  {action}
                </label>
              </div>
            ))}
          </div>
          <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-950/20 rounded-md border border-blue-200 dark:border-blue-800">
            <p className="text-sm text-blue-800 dark:text-blue-200">
              <strong>Note:</strong> These are AI-generated recommendations. Please review and validate each action
              before implementation in your security environment.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
