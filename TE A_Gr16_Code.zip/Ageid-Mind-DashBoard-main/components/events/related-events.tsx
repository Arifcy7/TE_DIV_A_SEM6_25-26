"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ExternalLink, Network, Clock } from "lucide-react"
import { formatDistanceToNow } from "date-fns"
import Link from "next/link"
import type { SecurityEvent } from "@/lib/types"

interface RelatedEventsProps {
  events: SecurityEvent[]
  currentEventId: string
}

const urgencyColors = {
  High: "destructive",
  Medium: "secondary",
  Low: "outline",
} as const

const eventTypeColors = {
  brute_force_login_attempt: "destructive",
  sql_injection_attempt: "destructive",
  malware_detection: "secondary",
  suspicious_network_traffic: "outline",
} as const

export function RelatedEvents({ events, currentEventId }: RelatedEventsProps) {
  if (events.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Network className="h-5 w-5" />
            Related Events
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center h-32 text-muted-foreground">
            <div className="text-center">
              <Network className="h-8 w-8 mx-auto mb-2" />
              <p>No related events found</p>
              <p className="text-sm">This appears to be an isolated incident</p>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Network className="h-5 w-5" />
          Related Events ({events.length})
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {events.map((event) => {
            const urgencyColor = event.final_urgency
              ? urgencyColors[event.final_urgency as keyof typeof urgencyColors]
              : "outline"
            const eventTypeColor = eventTypeColors[event.event_type as keyof typeof eventTypeColors] || "outline"

            return (
              <div key={event._id?.toString()} className="border rounded-lg p-4 hover:bg-muted/50 transition-colors">
                <div className="flex items-start justify-between">
                  <div className="space-y-2 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <Badge variant={eventTypeColor}>{event.event_type.replace(/_/g, " ")}</Badge>
                      {event.final_urgency && <Badge variant={urgencyColor}>{event.final_urgency}</Badge>}
                      {event.attack_confirmed && <Badge variant="destructive">Confirmed Attack</Badge>}
                    </div>

                    <div className="space-y-1 text-sm">
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <span className="font-medium">Source:</span>
                        <span className="font-mono">{event.source_ip}</span>
                        <span>→</span>
                        <span className="font-mono">{event.destination}</span>
                      </div>

                      {event.username && (
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <span className="font-medium">Target:</span>
                          <span className="font-mono">{event.username}</span>
                        </div>
                      )}

                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Clock className="h-3 w-3" />
                        <span>{formatDistanceToNow(new Date(event.timestamp), { addSuffix: true })}</span>
                      </div>
                    </div>

                    <div className="flex gap-4 text-xs text-muted-foreground">
                      <span>Anomaly: {(event.anomaly_score * 100).toFixed(0)}%</span>
                      <span>Confidence: {(event.detection_confidence * 100).toFixed(0)}%</span>
                      {event.failure_count && <span>Failures: {event.failure_count}</span>}
                    </div>
                  </div>

                  <Link href={`/events/${event._id}`}>
                    <Button variant="outline" size="sm" className="ml-4 bg-transparent">
                      <ExternalLink className="h-3 w-3" />
                    </Button>
                  </Link>
                </div>
              </div>
            )
          })}
        </div>

        {events.length >= 10 && (
          <div className="mt-4 text-center">
            <p className="text-sm text-muted-foreground">
              Showing first 10 related events. Use filters on the events page to see more.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
