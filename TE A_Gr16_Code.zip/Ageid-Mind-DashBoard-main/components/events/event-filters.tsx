"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { X, Search, Filter } from "lucide-react"

interface EventFiltersProps {
  onFiltersChange: (filters: EventFilters) => void
  onSearch: (search: string) => void
}

export interface EventFilters {
  urgency?: string
  event_type?: string
  source_ip?: string
  attack_confirmed?: boolean
  date_from?: string
  date_to?: string
}

interface FilterOptions {
  eventTypes: string[]
  sourceIPs: string[]
  urgencyLevels: string[]
}

export function EventFilters({ onFiltersChange, onSearch }: EventFiltersProps) {
  const [filters, setFilters] = useState<EventFilters>({})
  const [search, setSearch] = useState("")
  const [filterOptions, setFilterOptions] = useState<FilterOptions>({
    eventTypes: [],
    sourceIPs: [],
    urgencyLevels: [],
  })
  const [showFilters, setShowFilters] = useState(false)

  useEffect(() => {
    async function fetchFilterOptions() {
      try {
        const response = await fetch("/api/events/filters")
        const data = await response.json()
        setFilterOptions(data)
      } catch (error) {
        console.error("Error fetching filter options:", error)
      }
    }
    fetchFilterOptions()
  }, [])

  const handleFilterChange = (key: keyof EventFilters, value: string | boolean | undefined) => {
    const newFilters = { ...filters }
    if (value === "" || value === undefined) {
      delete newFilters[key]
    } else {
      newFilters[key] = value as any
    }
    setFilters(newFilters)
    onFiltersChange(newFilters)
  }

  const handleSearchChange = (value: string) => {
    setSearch(value)
    onSearch(value)
  }

  const clearFilters = () => {
    setFilters({})
    setSearch("")
    onFiltersChange({})
    onSearch("")
  }

  const activeFilterCount = Object.keys(filters).length + (search ? 1 : 0)

  return (
    <div className="space-y-4">
      {/* Search Bar */}
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search events by IP, destination, type, or username..."
            value={search}
            onChange={(e) => handleSearchChange(e.target.value)}
            className="pl-10"
          />
        </div>
        <Button variant="outline" onClick={() => setShowFilters(!showFilters)} className="flex items-center gap-2">
          <Filter className="h-4 w-4" />
          Filters
          {activeFilterCount > 0 && (
            <Badge variant="secondary" className="ml-1">
              {activeFilterCount}
            </Badge>
          )}
        </Button>
        {activeFilterCount > 0 && (
          <Button variant="outline" onClick={clearFilters}>
            Clear All
          </Button>
        )}
      </div>

      {/* Active Filters */}
      {activeFilterCount > 0 && (
        <div className="flex flex-wrap gap-2">
          {search && (
            <Badge variant="secondary" className="flex items-center gap-1">
              Search: {search}
              <X className="h-3 w-3 cursor-pointer" onClick={() => handleSearchChange("")} />
            </Badge>
          )}
          {Object.entries(filters).map(([key, value]) => (
            <Badge key={key} variant="secondary" className="flex items-center gap-1">
              {key.replace(/_/g, " ")}: {String(value)}
              <X
                className="h-3 w-3 cursor-pointer"
                onClick={() => handleFilterChange(key as keyof EventFilters, undefined)}
              />
            </Badge>
          ))}
        </div>
      )}

      {/* Filter Panel */}
      {showFilters && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Filter Events</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              <div className="space-y-2">
                <Label htmlFor="urgency">Urgency Level</Label>
                <Select
                  value={filters.urgency || "all_urgency_levels"}
                  onValueChange={(value) => handleFilterChange("urgency", value || undefined)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="All urgency levels" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all_urgency_levels">All urgency levels</SelectItem>
                    {filterOptions.urgencyLevels.map((level) => (
                      <SelectItem key={level} value={level}>
                        {level}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="event_type">Event Type</Label>
                <Select
                  value={filters.event_type || "all_event_types"}
                  onValueChange={(value) => handleFilterChange("event_type", value || undefined)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="All event types" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all_event_types">All event types</SelectItem>
                    {filterOptions.eventTypes.map((type) => (
                      <SelectItem key={type} value={type}>
                        {type.replace(/_/g, " ")}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="attack_confirmed">Attack Status</Label>
                <Select
                  value={filters.attack_confirmed?.toString() || "all_statuses"}
                  onValueChange={(value) =>
                    handleFilterChange("attack_confirmed", value === "" ? undefined : value === "true")
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="All statuses" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all_statuses">All statuses</SelectItem>
                    <SelectItem value="true">Confirmed Attacks</SelectItem>
                    <SelectItem value="false">Not Confirmed</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="date_from">From Date</Label>
                <Input
                  type="date"
                  value={filters.date_from || ""}
                  onChange={(e) => handleFilterChange("date_from", e.target.value || undefined)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="date_to">To Date</Label>
                <Input
                  type="date"
                  value={filters.date_to || ""}
                  onChange={(e) => handleFilterChange("date_to", e.target.value || undefined)}
                />
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
