"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { formatDistanceToNow, format } from "date-fns"
import Link from "next/link"
import { ExternalLink, Shield, AlertTriangle, Clock, Target, User, Brain } from "lucide-react"
import type { SecurityEvent, SecurityAnalysis } from "@/lib/types"

interface EventCardProps {
  event: SecurityEvent & { analysis?: SecurityAnalysis }
}

const urgencyColors = {
  High: "destructive",
  Medium: "secondary",
  Low: "outline",
} as const

const eventTypeColors = {
  brute_force_login_attempt: "destructive",
  sql_injection_attempt: "destructive",
  malware_detection: "secondary",
  suspicious_network_traffic: "outline",
} as const

export function EventCard({ event }: EventCardProps) {
  const urgencyColor = event.final_urgency
    ? urgencyColors[event.final_urgency as keyof typeof urgencyColors]
    : "outline"

  const eventTypeColor = eventTypeColors[event.event_type as keyof typeof eventTypeColors] || "outline"

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div className="space-y-3 flex-1">
            {/* Header with badges */}
            <div className="flex flex-wrap items-center gap-2">
              <Badge variant={eventTypeColor}>{event.event_type.replace(/_/g, " ")}</Badge>
              {event.final_urgency && (
                <Badge variant={urgencyColor}>
                  <AlertTriangle className="mr-1 h-3 w-3" />
                  {event.final_urgency}
                </Badge>
              )}
              {event.attack_confirmed && (
                <Badge variant="destructive">
                  <Shield className="mr-1 h-3 w-3" />
                  Confirmed Attack
                </Badge>
              )}
              <Badge variant="outline">{event.status === "analyzed" ? "Analyzed" : "Pending Analysis"}</Badge>
              {event.analysis && (
                <Badge variant="secondary">
                  <Brain className="mr-1 h-3 w-3" />
                  AI Analysis
                </Badge>
              )}
            </div>

            {/* Event details */}
            <div className="grid gap-2 text-sm">
              <div className="flex items-center gap-2 text-muted-foreground">
                <Target className="h-4 w-4" />
                <span className="font-medium">Source:</span>
                <span className="font-mono">{event.source_ip}</span>
                <span>→</span>
                <span className="font-mono">{event.destination}</span>
              </div>

              {event.username && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <User className="h-4 w-4" />
                  <span className="font-medium">Target User:</span>
                  <span className="font-mono">{event.username}</span>
                </div>
              )}

              <div className="flex items-center gap-2 text-muted-foreground">
                <Clock className="h-4 w-4" />
                <span className="font-medium">Time:</span>
                <span>{format(new Date(event.timestamp), "MMM dd, yyyy HH:mm:ss")}</span>
                <span className="text-xs">({formatDistanceToNow(new Date(event.timestamp), { addSuffix: true })})</span>
              </div>
            </div>

            {/* AI analysis preview section */}
            {event.analysis && (
              <div className="p-3 bg-muted/50 rounded-md border-l-4 border-l-blue-500">
                <div className="flex items-center gap-2 mb-2">
                  <Brain className="h-4 w-4 text-blue-600" />
                  <span className="text-sm font-medium text-blue-800 dark:text-blue-200">AI Analysis Summary</span>
                </div>
                <p className="text-sm text-muted-foreground line-clamp-2">
                  {event.analysis.reasoning.substring(0, 150)}...
                </p>
                <div className="flex items-center gap-2 mt-2">
                  <Badge
                    variant={
                      event.analysis.urgency === "High"
                        ? "destructive"
                        : event.analysis.urgency === "Medium"
                          ? "secondary"
                          : "outline"
                    }
                  >
                    {event.analysis.urgency} Priority
                  </Badge>
                  <span className="text-xs text-muted-foreground">
                    {event.analysis.recommended_actions.length} recommendations
                  </span>
                </div>
              </div>
            )}

            {/* Metrics */}
            <div className="flex gap-4 text-sm">
              <div>
                <span className="font-medium text-muted-foreground">Anomaly Score:</span>
                <span
                  className={`ml-1 font-mono ${event.anomaly_score > 0.8 ? "text-destructive" : event.anomaly_score > 0.5 ? "text-yellow-600" : "text-green-600"}`}
                >
                  {(event.anomaly_score * 100).toFixed(0)}%
                </span>
              </div>
              <div>
                <span className="font-medium text-muted-foreground">Confidence:</span>
                <span className="ml-1 font-mono">{(event.detection_confidence * 100).toFixed(0)}%</span>
              </div>
              {event.failure_count && (
                <div>
                  <span className="font-medium text-muted-foreground">Failures:</span>
                  <span className="ml-1 font-mono text-destructive">{event.failure_count}</span>
                </div>
              )}
            </div>

            {/* Asset criticality */}
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium text-muted-foreground">Asset Criticality:</span>
              <Badge
                variant={
                  event.asset_criticality === "high"
                    ? "destructive"
                    : event.asset_criticality === "medium"
                      ? "secondary"
                      : "outline"
                }
              >
                {event.asset_criticality}
              </Badge>
            </div>
          </div>

          {/* Action button */}
          <div className="ml-4">
            <Link
              href={`/events/${event._id}`}
              className="inline-flex items-center gap-1 text-sm text-primary hover:underline"
            >
              View Details
              <ExternalLink className="h-3 w-3" />
            </Link>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
